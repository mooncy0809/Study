package dev.mvc.cart;

import java.util.List;

public interface CartDAOInter {
  /**
   * 카트에 상품 등록
   * @param cartVO
   * @return
   */
  public int create(CartVO cartVO);
  
  /**
   * memberno 회원 번호별 쇼핑카트 목록 출력
   * @return
   */
  public List<CartVO> list_by_memberno(int memberno);
}
 