package dev.mvc.tensorflow;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class TensorflowCont {
  public TensorflowCont() {
    System.out.println("-> TensorflowCont created.");
  }

  // http://localhost:9091/tensorflow/country.do
  @RequestMapping(value = {"/tensorflow/country.do"}, method = RequestMethod.GET)
  public ModelAndView country() {
    ModelAndView mav = new ModelAndView();
    mav.setViewName("/tensorflow/country");  // /WEB-INF/views/tensorflow/country.jsp
    
    return mav;
  }
  
  // http://localhost:9091/tensorflow/wine.do
  @RequestMapping(value = {"/tensorflow/wine.do"}, method = RequestMethod.GET)
  public ModelAndView wine() {
    ModelAndView mav = new ModelAndView();
    mav.setViewName("/tensorflow/wine");  // /WEB-INF/views/tensorflow/wine.jsp
    
    return mav;
  }
  
  
  // http://localhost:9091/tensorflow/iris.do
  @RequestMapping(value = {"/tensorflow/iris.do"}, method = RequestMethod.GET)
  public ModelAndView iris() {
    ModelAndView mav = new ModelAndView();
    mav.setViewName("/tensorflow/iris");  // /WEB-INF/views/tensorflow/iris.jsp
    
    return mav;
  }
  
}