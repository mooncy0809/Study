package dev.mvc.byou;

import java.util.List;

public interface YouProcInter {
    /**
     * 등록
     * @param youVO
     * @return 등록된 갯수
     */
    public int create(YouVO youVO);
    
    /**
     *  전체 목록
     * @return
     */
    public List<YouVO> list_all();  
    
    /**
     *  ytgrpno별 목록
     * @return
     */
    public List<YouVO> list_by_ytgrpno(int ytgrpno);   
    
    /**
     *Ytgrp_YouVO, 연결 목록
     * @return
     */
    public List<Ytgrp_YouVO> list_all_join();  
    /**
     * 조회, 수정폼
     * @param youno 카테고리 번호, PK
     * @return
     */
    public YouVO read(int youno);
    
    /**
     * 수정 처리
     * @param youVO
     * @return 수정된 레코드 갯수
     */
    public int update(YouVO youVO);
    
    /**
     * 삭제 처리 
     * @param cateno
     * @return 삭제된 레코드 갯수
     */
    public int delete(int youno);
}
