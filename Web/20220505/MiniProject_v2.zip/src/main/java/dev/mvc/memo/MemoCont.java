package dev.mvc.memo;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import dev.mvc.bcategrp.BcategrpVO;
//import dev.mvc.member.MemberProcInter;
import dev.mvc.tool.Tool;
import dev.mvc.tool.Upload;

@Controller
public class MemoCont {
    @Autowired
    @Qualifier("dev.mvc.memo.MemoProc")
    private MemoProcInter memoProc;
    
    public MemoCont() {
      System.out.println("-> MemoCont created.");
    }

    /**
     * 새로고침 방지
     * @return
     */
    @RequestMapping(value="/memo/msg.do", method=RequestMethod.GET)
    public ModelAndView msg(String url){
      ModelAndView mav = new ModelAndView();

      mav.setViewName(url); // forward
      
      return mav; // forward
    }
    
    /**
     * 등록폼 
     * http://localhost:9091/memo/create.do?adminno=1 FK 값 명시
     * 
     * @return
     */
    @RequestMapping(value = "/memo/create.do", method = RequestMethod.GET)
    public ModelAndView create(int adminno) {
      ModelAndView mav = new ModelAndView();
      mav.setViewName("/memo/create"); 
      return mav; // forward
    }
    /**
     * 등록 처리 http://localhost:9091/memo/create.do
     * 
     * @return
     */
    @RequestMapping(value = "/memo/create.do", method = RequestMethod.POST)
    public ModelAndView create(HttpServletRequest request, MemoVO memoVO) {
      ModelAndView mav = new ModelAndView();
      
      // ------------------------------------------------------------------------------
      // 파일 전송 코드 시작
      // ------------------------------------------------------------------------------
      String file1 = "";          // 원본 파일명 image
      String file1saved = "";  // 저장된 파일명, image
      String thumb1 = "";     // preview image

      // 기준 경로 확인
      String user_dir = System.getProperty("user.dir"); // 시스템 제공
      System.out.println("-> User dir: " + user_dir);
      //  --> User dir: C:\kd1\ws_java\resort_v1sbm3c
      
      // 파일 접근임으로 절대 경로 지정, static 폴더 지정
      // 완성된 경로 C:/kd1/ws_java/resort_v1sbm3c/src/main/resources/static/memo/storage
      String upDir =  user_dir + "/src/main/resources/static/memo/storage/"; // 절대 경로
      System.out.println("-> upDir: " + upDir);
      
      // 전송 파일이 없어도 file1MF 객체가 생성됨.
      // <input type='file' class="form-control" name='file1MF' id='file1MF' 
      //           value='' placeholder="파일 선택">
      MultipartFile mf = memoVO.getFile1MF();
      
      file1 = Tool.getFname(mf.getOriginalFilename()); // 원본 순수 파일명 산출
      // System.out.println("-> file1: " + file1);
      
      long size1 = mf.getSize();  // 파일 크기
      
      if (size1 > 0) { // 파일 크기 체크
        // 파일 저장 후 업로드된 파일명이 리턴됨, spring.jsp, spring_1.jpg...
        file1saved = Upload.saveFileSpring(mf, upDir); 
        
        if (Tool.isImage(file1saved)) { // 이미지인지 검사
          // thumb 이미지 생성후 파일명 리턴됨, width: 200, height: 150
          thumb1 = Tool.preview(upDir, file1saved, 200, 150); 
        }   
      }    
      
      memoVO.setFile1(file1);
      memoVO.setFile1saved(file1saved);
      memoVO.setThumb1(thumb1);
      memoVO.setSize1(size1);
      // ------------------------------------------------------------------------------
      // 파일 전송 코드 종료
      // ------------------------------------------------------------------------------
      
      // Call By Reference: 메모리 공유, Hashcode 전달
      int cnt = this.memoProc.create(memoVO); 
      
      // ------------------------------------------------------------------------------
      // PK의 return
      // ------------------------------------------------------------------------------
       System.out.println("--> memono: " + memoVO.getMemono());
       mav.addObject("memono", memoVO.getMemono()); // redirect parameter 적용
      // ------------------------------------------------------------------------------
      
      if (cnt == 1) {
          mav.addObject("code", "create_success");
      } else {
          mav.addObject("code", "create_fail");
      }
      mav.addObject("cnt", cnt); 
      
      mav.addObject("url", "/memo/msg"); // msg.jsp, redirect parameter 적용

      mav.setViewName("redirect:/memo/msg.do"); 
      
      return mav; // forward
    }
    
    /**
     * 출력 모드의 변경
     * @param memoVO
     * @return
     */
    @RequestMapping(value="/memo/update_sw.do", method=RequestMethod.GET )
    public ModelAndView update_sw(int memono) {
      ModelAndView mav = new ModelAndView();      
      
      MemoVO memoVO = this.memoProc.read(memono);
      mav.addObject("memoVO", memoVO);  // request 객체에 저장

      String sw = memoVO.getSw();
      System.out.println(sw);
      
      mav.addObject("memono", memoVO.getMemono()); // redirect parameter 적용
      System.out.println(memono);
      
      mav.setViewName("redirect:/memo/list.do"); // request 객체 전달 안됨. 
      
      return mav;
    }   
    
    /**
     * 출력 모드 수정 처리
     * 
     * @param categrpVO
     * @return
     */
//    @RequestMapping(value="/memo/update_sw.do", 
//            method=RequestMethod.GET )
//        public ModelAndView update_visible(MemoVO memoVO) {
//          ModelAndView mav = new ModelAndView();
//
//          int cnt = this.memoProc.update_sw(memoVO);
//          
//          mav.setViewName("redirect:/memo/list.do"); // request 객체 전달 안됨. 
//          
//          return mav;
//    }
    /**
     * 목록 + 검색 + 페이징 지원     * 
     * @param word
     * @param now_page
     * @return
     */
    @RequestMapping(value = "/memo/list.do", method = RequestMethod.GET)
    public ModelAndView list(@RequestParam(value = "word", defaultValue = "") String word,
                                                                           @RequestParam(value = "now_page", defaultValue = "1") int now_page) {
      System.out.println("--> now_page: " + now_page);

      ModelAndView mav = new ModelAndView();

      // 숫자와 문자열 타입을 저장해야함으로 Obejct 사용
      HashMap<String, Object> map = new HashMap<String, Object>();
      map.put("word", word); // #{word}
      map.put("now_page", now_page); // 페이지에 출력할 레코드의 범위를 산출하기위해 사용

      // 검색 목록
      List<MemoVO> list = memoProc.list(map);
      mav.addObject("list", list);

      // 검색된 레코드 갯수
      int search_count = memoProc.search_count(map);
      mav.addObject("search_count", search_count);


      /*
       * SPAN태그를 이용한 박스 모델의 지원, 1 페이지부터 시작 현재 페이지: 11 / 22 [이전] 11 12 13 14 15 16 17
       * 18 19 20 [다음]
       * @param search_count 검색(전체) 레코드수
       * @param now_page 현재 페이지
       * @param word 검색어
       * @return 페이징 생성 문자열
       */
      String paging = memoProc.pagingBox(search_count, now_page, word);
      mav.addObject("paging", paging);

      mav.addObject("now_page", now_page);

      mav.setViewName("/memo/list");

      return mav;
    }
    
    /**
     * 조회
     * @return
     */
    @RequestMapping(value="/memo/read.do", method=RequestMethod.GET )
    public ModelAndView read(int memono) {
      ModelAndView mav = new ModelAndView();

      MemoVO memoVO = this.memoProc.read(memono);
      mav.addObject("memoVO", memoVO);

      mav.setViewName("/memo/read"); 
          
      return mav;
    }
    
    /**
     * 수정 폼
     * http://localhost:9091/memo/update_text.do?memono=1
     * 
     * @return
     */
    @RequestMapping(value = "/memo/update_text.do", method = RequestMethod.GET)
    public ModelAndView update_text(int memono) {
      ModelAndView mav = new ModelAndView();
      
      MemoVO memoVO = this.memoProc.read_update_text(memono);

      mav.addObject("memoVO", memoVO);

      
      mav.setViewName("/memo/update_text");
      return mav; // forward
    }

    /**
     * 수정 처리
     * http://localhost:9091/memo/update_text.do?memono=1
     * 
     * @return
     */
    @RequestMapping(value = "/memo/update_text.do", method = RequestMethod.POST)
    public ModelAndView update_text(MemoVO memoVO,
                                                    @RequestParam(value = "word", defaultValue = "") String word,
                                                    @RequestParam(value = "now_page", defaultValue = "1") int now_page) {
      ModelAndView mav = new ModelAndView();
      
      HashMap<String, Object> map = new HashMap<String, Object>();
      map.put("memono", memoVO.getMemono());
      
      int cnt = 0;
      cnt = this.memoProc.update_text(memoVO); // 수정 처리
          
      mav.addObject("now_page", now_page);
      mav.addObject("memono", memoVO.getMemono());
      mav.setViewName("redirect:/memo/read.do");             


      return mav; // forward
    }
    /**
     * 파일 수정 폼
     * http://localhost:9091/memo/update_file.do?memono=1
     * 
     * @return
     */
    @RequestMapping(value = "/memo/update_file.do", method = RequestMethod.GET)
    public ModelAndView update_file(int memono) {
      ModelAndView mav = new ModelAndView();
      
      MemoVO memoVO = this.memoProc.read(memono);
      
      mav.addObject("memoVO", memoVO);
      
      mav.setViewName("/memo/update_file"); // /WEB-INF/views/memo/update_file.jsp

      return mav; // forward
    }
  /**
   * 파일 수정 처리 http://localhost:9091/memo/update_file.do
   * 
   * @return
   */
  @RequestMapping(value = "/memo/update_file.do", method = RequestMethod.POST)
  public ModelAndView update_file(HttpServletRequest request, MemoVO memoVO, @RequestParam(value = "now_page", defaultValue = "1") int now_page) {
    ModelAndView mav = new ModelAndView();
    
    // System.out.println("-> now_page: " + now_page);
    
    // 삭제할 파일 정보를 읽어옴, 기존에 등록된 레코드 저장용
    MemoVO memoVO_old = memoProc.read(memoVO.getMemono());
    
    HashMap<String, Object> map = new HashMap<String, Object>();
    map.put("memono", memoVO.getMemono());
    
    int cnt = 0;
    int passwd_cnt = 1;
    if (passwd_cnt == 1) { // 패스워드 일치 -> 등록된 파일 삭제 -> 신규 파일 등록
        // -------------------------------------------------------------------
        // 파일 삭제 코드 시작
        // -------------------------------------------------------------------
//        System.out.println("memono: " + vo.getMemono());
//        System.out.println("file1: " + vo.getFile1());
        
        String file1saved = memoVO_old.getFile1saved(); // 실제 저장된 파일명
        String thumb1 = memoVO_old.getThumb1();       // 실제 저장된 preview 이미지 파일명
        long size1 = 0;
        boolean sw = false;
        
        // 완성된 경로 C:/kd/ws_java/resort_v1sbm3c/src/main/resources/static/memo/storage/
        String user_dir = System.getProperty("user.dir"); // 시스템 제공
        String upDir =  user_dir + "/src/main/resources/static/memo/storage/"; // 절대 경로


        sw = Tool.deleteFile(upDir, file1saved);  // Folder에서 1건의 파일 삭제
        sw = Tool.deleteFile(upDir, thumb1);     // Folder에서 1건의 파일 삭제
        // System.out.println("sw: " + sw);
        // -------------------------------------------------------------------
        // 파일 삭제 종료 시작
        // -------------------------------------------------------------------
        
        // -------------------------------------------------------------------
        // 파일 전송 코드 시작
        // -------------------------------------------------------------------
        String file1 = "";          // 원본 파일명 image

        // 완성된 경로 F:/ai8/ws_frame/resort_v1sbm3a/src/main/resources/static/memo/storage/
        // String upDir =  System.getProperty("user.dir") + "/src/main/resources/static/memo/storage/"; // 절대 경로
        
        // 전송 파일이 없어도 fnamesMF 객체가 생성됨.
        // <input type='file' class="form-control" name='file1MF' id='file1MF' 
        //           value='' placeholder="파일 선택">
        MultipartFile mf = memoVO.getFile1MF();
        
        file1 = mf.getOriginalFilename(); // 원본 파일명
        size1 = mf.getSize();  // 파일 크기
        
        if (size1 > 0) { // 파일 크기 체크
          // 파일 저장 후 업로드된 파일명이 리턴됨, spring.jsp, spring_1.jpg...
          file1saved = Upload.saveFileSpring(mf, upDir); 
          
          if (Tool.isImage(file1saved)) { // 이미지인지 검사
            // thumb 이미지 생성후 파일명 리턴됨, width: 250, height: 200
            thumb1 = Tool.preview(upDir, file1saved, 250, 200); 
          }
          
        } else { // 파일이 삭제만 되고 새로 올리지 않는 경우
            file1="";
            file1saved="";
            thumb1="";
            size1=0;
        }
        
        memoVO.setFile1(file1);
        memoVO.setFile1saved(file1saved);
        memoVO.setThumb1(thumb1);
        memoVO.setSize1(size1);
        // -------------------------------------------------------------------
        // 파일 전송 코드 종료
        // -------------------------------------------------------------------
        
        // Call By Reference: 메모리 공유, Hashcode 전달
        cnt = this.memoProc.update_file(memoVO);
        // System.out.println("-> cnt: " + cnt);
        
        // request.setAttribute("now_page", now_page);
        mav.addObject("now_page", now_page);
        mav.addObject("memono", memoVO.getMemono());
        mav.setViewName("redirect:/memo/read.do"); // request -> param으로 접근 전환
        
    } else { // 패스워드 오류
        mav.addObject("cnt", cnt);
        mav.addObject("code", "passwd_fail");
        mav.addObject("url", "/memo/msg"); // msg.jsp, redirect parameter 적용
        mav.setViewName("redirect:/memo/msg.do");
    }
    
    return mav; // forward
  }   
    /**
     * 삭제 폼
     * @param memono
     * @return
     */
    @RequestMapping(value="/memo/delete.do", method=RequestMethod.GET )
    public ModelAndView delete(int memono) { 
      ModelAndView mav = new  ModelAndView();
      
      // 삭제할 정보를 조회하여 확인
      MemoVO memoVO = this.memoProc.read(memono);
      
      mav.addObject("memoVO", memoVO);
      mav.setViewName("/memo/delete");  // memo/delete.jsp
      
      return mav; 
    }

    /**
     * 삭제 처리 http://localhost:9091/memo/delete.do
     * 
     * @return
     */
    @RequestMapping(value = "/memo/delete.do", method = RequestMethod.POST)
    public ModelAndView delete(HttpServletRequest request, MemoVO memoVO, 
                                            @RequestParam(value = "now_page", defaultValue = "1") int now_page,
                                            @RequestParam(value="word", defaultValue="") String word) {
      ModelAndView mav = new ModelAndView();
      int memono = memoVO.getMemono();
      
      int cnt = 0;
      int passwd_cnt = 1;
      if (passwd_cnt == 1) { // 패스워드 일치 -> 등록된 파일 삭제 -> 신규 파일 등록
          // -------------------------------------------------------------------
          // 파일 삭제 코드 시작
          // -------------------------------------------------------------------
          // 삭제할 파일 정보를 읽어옴.
          MemoVO vo = memoProc.read(memono);
//          System.out.println("memono: " + vo.getMemono());
//          System.out.println("file1: " + vo.getFile1());
          
          String file1saved = vo.getFile1saved();
          String thumb1 = vo.getThumb1();
          long size1 = 0;
          boolean sw = false;
          
          // 완성된 경로 F:/ai8/ws_frame/resort_v1sbm3a/src/main/resources/static/memo/storage/
          String upDir =  System.getProperty("user.dir") + "/src/main/resources/static/memo/storage/"; // 절대 경로

          sw = Tool.deleteFile(upDir, file1saved);  // Folder에서 1건의 파일 삭제
          sw = Tool.deleteFile(upDir, thumb1);     // Folder에서 1건의 파일 삭제
          // System.out.println("sw: " + sw);
          // -------------------------------------------------------------------
          // 파일 삭제 종료 시작
          // -------------------------------------------------------------------
          
          cnt = this.memoProc.delete(memono); // DBMS 삭제
          
          // -------------------------------------------------------------------------------------
          System.out.println("-> word: " + word);
          
          // 마지막 페이지의 레코드 삭제시의 페이지 번호 -1 처리
          HashMap<String, Object> page_map = new HashMap<String, Object>();
          page_map.put("word", word);
          // 10번째 레코드를 삭제후
          // 하나의 페이지가 3개의 레코드로 구성되는 경우 현재 9개의 레코드가 남아 있으면
          // 페이지수를 4 -> 3으로 감소 시켜야함.
          if (memoProc.search_count(page_map) % Memo.RECORD_PER_PAGE == 0) {
            now_page = now_page - 1;
            if (now_page < 1) {
              now_page = 1; // 시작 페이지
            }
          }
          // -------------------------------------------------------------------------------------
          
          mav.addObject("now_page", now_page);
          mav.setViewName("redirect:/memo/list.do"); 

      }
      
      return mav; // forward
    }   
}
