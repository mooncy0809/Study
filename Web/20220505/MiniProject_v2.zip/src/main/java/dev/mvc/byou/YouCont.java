package dev.mvc.byou;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import dev.mvc.bytgrp.YtgrpProcInter;
import dev.mvc.bytgrp.YtgrpVO;
import dev.mvc.tool.Tool;


@Controller
public class YouCont {
    @Autowired
    @Qualifier("dev.mvc.bytgrp.YtgrpProc")
    private YtgrpProcInter ytgrpProc;
    @Autowired
    @Qualifier("dev.mvc.byou.YouProc") 
    private YouProcInter youProc;
 
    public YouCont() {
        System.out.println("-> YouCont created.");
    }
    
    /**
     * 등록폼 
     * @return
     */
    @RequestMapping(value = "/byou/create.do", method = RequestMethod.GET)
    public ModelAndView create() {
      ModelAndView mav = new ModelAndView();
      mav.setViewName("/byou/create"); // /webapp/WEB-INF/views/byou/create.jsp

      return mav;
      
    }
    
    /**
     * 등록처리
     * @return
     */
    @RequestMapping(value = "/byou/create.do", method = RequestMethod.POST)
    public ModelAndView create(YouVO youVO) {
      ModelAndView mav = new ModelAndView();
      int cnt = this.youProc.create(youVO);
      System.out.println("등록 성공");

      mav.addObject("code", "create_success");
      mav.addObject("cnt", cnt);
      mav.addObject("ytgrpno", youVO.getYtgrpno());
      mav.addObject("title", youVO.getTitle());
      mav.addObject("url", youVO.getUrl());
      mav.setViewName("/byou/msg");
 
      return mav;
    }
    
    
    /**
     * 전체 목록
     * @return
     */
    @RequestMapping(value="/byou/list_all.do", method=RequestMethod.GET )
    public ModelAndView list_all() {
      ModelAndView mav = new ModelAndView();
      
      List<YouVO> list = this.youProc.list_all();
      mav.addObject("list", list); // request.setAttribute("list", list);

      mav.setViewName("/byou/list_all"); // /byou/list_all.jsp
      return mav;
    }
    /**
     * 카테고리 그룹별 전체 목록
     * http://localhost:9091/byou/list_by_ytgrpno.do?ytgrpno=1
     * @param ytgrpno 특정 그룹에 소속된 카테고리를 출력할 카테고리 그룹 번호   
     * @return
     */
    @RequestMapping(value="/byou/list_by_ytgrpno.do", method=RequestMethod.GET )
    public ModelAndView list_by_ytgrpno(int ytgrpno) {
      ModelAndView mav = new ModelAndView();
      
      List<YouVO> list = this.youProc.list_by_ytgrpno(ytgrpno);
      mav.addObject("list", list);

      YtgrpVO  ytgrpVO = this.ytgrpProc.read(ytgrpno); // 카테고리 그룹 정보
      mav.addObject("ytgrpVO", ytgrpVO); 
      
      mav.setViewName("/byou/list_by_ytgrpno"); 
      return mav;
    }
    
    /**
     * Ytgrp + You join, 연결 목록
     * http://localhost:9091/byou/list_all_join.do 
     * @return
     */
    @RequestMapping(value="/byou/list_all_join.do", method=RequestMethod.GET )
    public ModelAndView list_all_join() {
      ModelAndView mav = new ModelAndView();
      
      List<Ytgrp_YouVO> list = this.youProc.list_all_join();
      mav.addObject("list", list); 

      mav.setViewName("/byou/list_all_join");
      return mav;
    }
    
    /**
     * 조회 + 수정폼 http://localhost:9091/you/read_update.do
     * 
     * @return
     */
    @RequestMapping(value = "/byou/read_update.do", method = RequestMethod.GET)
    public ModelAndView read_update(int youno) {
      // int youno = Integer.parseInt(request.getParameter("youno"));

      ModelAndView mav = new ModelAndView();
      mav.setViewName("/byou/read_update"); // read_update.jsp

      // 카테고리 정보
      YouVO youVO = this.youProc.read(youno);
      mav.addObject("youVO", youVO);
      // request.setAttribute("youVO", youVO);
      
      int ytgrpno = youVO.getYtgrpno();
      
      // 카테고리 그룹 정보
      YtgrpVO ytgrpVO = this.ytgrpProc.read(ytgrpno);
      mav.addObject("ytgrpVO", ytgrpVO);

      // 카테고리 목록
      List<YouVO> list = this.youProc.list_by_ytgrpno(ytgrpno);
      mav.addObject("list", list);

      return mav; // forward
    }
    
    /**
     * 수정 처리
     * 
     * @param youVO
     * @return
     */
    @RequestMapping(value = "/byou/update.do", method = RequestMethod.POST)
    public ModelAndView update(YouVO youVO) {
      ModelAndView mav = new ModelAndView();

      int cnt = this.youProc.update(youVO);
      
      if (cnt == 1) {
          mav.addObject("ytgrpno", youVO.getYtgrpno());
          mav.setViewName("redirect:/byou/list_by_ytgrpno.do");
      } else {
          mav.addObject("code", "update_fail"); // request에 저장
          mav.addObject("cnt", cnt); // request에 저장
          mav.addObject("youno", youVO.getYouno());
          mav.addObject("ytgrpno", youVO.getYtgrpno());
          mav.addObject("name", youVO.getTitle());
          mav.addObject("url", "/byou/msg"); 
          
          mav.setViewName("/byou/msg"); 
          
      }
      
      return mav;
    }
 
    /**
     * 
     * @return
     */
    @RequestMapping(value = "/byou/read_delete.do", method = RequestMethod.GET)
    public ModelAndView read_delete(int youno) {
      // int youno = Integer.parseInt(request.getParameter("youno"));
      ModelAndView mav = new ModelAndView();
      mav.setViewName("/byou/read_delete");

      YouVO youVO = this.youProc.read(youno);
      mav.addObject("youVO", youVO);
      int ytgrpno = youVO.getYtgrpno();
      
      YtgrpVO ytgrpVO = this.ytgrpProc.read(ytgrpno);
      mav.addObject("ytgrpVO", ytgrpVO);
      

      List<YouVO> list = this.youProc.list_by_ytgrpno(ytgrpno);
      mav.addObject("list", list);

      return mav; // forward
    }
    
    /**
     * 삭제 처리
     * 
     * @param youVO
     * @return
     */
    @RequestMapping(value = "/byou/delete.do", method = RequestMethod.POST)
    public ModelAndView delete(int youno) {
      ModelAndView mav = new ModelAndView();
      // 삭제될 레코드 정보를 삭제하기전에 읽음
      YouVO youVO = this.youProc.read(youno); 
      
      int cnt = this.youProc.delete(youno);
      
      if (cnt == 1) {
          mav.addObject("ytgrpno", youVO.getYtgrpno());
          mav.setViewName("redirect:/byou/list_by_ytgrpno.do");
      } else {
          mav.addObject("code", "update_fail"); // request에 저장
          mav.addObject("cnt", cnt); // request에 저장
          mav.addObject("youno", youVO.getYouno());
          mav.addObject("ytgrpno", youVO.getYtgrpno());
          mav.addObject("name", youVO.getTitle());
          mav.addObject("url", "/byou/msg"); 
          
          mav.setViewName("/byou/msg"); // /WEB-INF/views/you/msg.jsp
          
      }
      
      return mav;
    }
    /**
     * Grid 형태의 화면 구성
     * 
     * @return
     */
    @RequestMapping(value = "/byou/list_by_ytgrpno_grid.do", method = RequestMethod.GET)
    public ModelAndView list_by_ytgrpno_grid(int ytgrpno) {
      ModelAndView mav = new ModelAndView();
      
      YtgrpVO ytgrpVO = this.ytgrpProc.read(ytgrpno);
      mav.addObject("ytgrpVO", ytgrpVO);
      
      
      List<YouVO> list = this.youProc.list_by_ytgrpno(ytgrpno);
      mav.addObject("list", list);

      mav.setViewName("/byou/list_by_ytgrpno_grid");

      return mav; // forward
    }
    
}

