package dev.mvc.cart;

public interface CartDAOInter {
  /**
   * 카트에 상품 등록
   * @param cartVO
   * @return
   */
  public int create(CartVO cartVO);
  
}
 