package dev.mvc.cart;

/*
  cartno                        NUMBER(10) NOT NULL PRIMARY KEY,
  contentsno                 NUMBER(10) NULL ,
  memberno                 NUMBER(10) NOT NULL,
  cnt                            NUMBER(10) DEFAULT 0 NOT NULL,
  tot                            NUMBER(10) DEFAULT 0 NOT NULL,
  rdate                          DATE NOT NULL,
  
  SELECT t.cartno, c.contentsno, c.title, c.thumb1, c.price, c.dc, c.saleprice, c.point, t.memberno, t.cnt, t.tot, t.rdate 
 */
public class CartVO {
  /** 쇼핑 카트 번호 */
  private int cartno;
  /** 컨텐츠 번호 */
  private int contentsno;
  /** 제목 */
  private String title = "";
  /** 메인 이미지 preview */
  private String thumb1 = "";
  /** 정가 */
  private int price;
  /** 할인률 */
  private int dc;
  /** 판매가 */
  private int saleprice;
  /** 포인트 */
  private int point;
  /** 회원 번호 */
  private int memberno;
  /** 수량 */
  private int cnt;
  /** 금액 = 판매가 x 수량 */
  private int tot;
  /** 등록일 */
  private String rdate;
/**
 * @return the cartno
 */
public int getCartno() {
    return cartno;
}
/**
 * @param cartno the cartno to set
 */
public void setCartno(int cartno) {
    this.cartno = cartno;
}
/**
 * @return the contentsno
 */
public int getContentsno() {
    return contentsno;
}
/**
 * @param contentsno the contentsno to set
 */
public void setContentsno(int contentsno) {
    this.contentsno = contentsno;
}
/**
 * @return the title
 */
public String getTitle() {
    return title;
}
/**
 * @param title the title to set
 */
public void setTitle(String title) {
    this.title = title;
}
/**
 * @return the thumb1
 */
public String getThumb1() {
    return thumb1;
}
/**
 * @param thumb1 the thumb1 to set
 */
public void setThumb1(String thumb1) {
    this.thumb1 = thumb1;
}
/**
 * @return the price
 */
public int getPrice() {
    return price;
}
/**
 * @param price the price to set
 */
public void setPrice(int price) {
    this.price = price;
}
/**
 * @return the dc
 */
public int getDc() {
    return dc;
}
/**
 * @param dc the dc to set
 */
public void setDc(int dc) {
    this.dc = dc;
}
/**
 * @return the saleprice
 */
public int getSaleprice() {
    return saleprice;
}
/**
 * @param saleprice the saleprice to set
 */
public void setSaleprice(int saleprice) {
    this.saleprice = saleprice;
}
/**
 * @return the point
 */
public int getPoint() {
    return point;
}
/**
 * @param point the point to set
 */
public void setPoint(int point) {
    this.point = point;
}
/**
 * @return the memberno
 */
public int getMemberno() {
    return memberno;
}
/**
 * @param memberno the memberno to set
 */
public void setMemberno(int memberno) {
    this.memberno = memberno;
}
/**
 * @return the cnt
 */
public int getCnt() {
    return cnt;
}
/**
 * @param cnt the cnt to set
 */
public void setCnt(int cnt) {
    this.cnt = cnt;
}
/**
 * @return the tot
 */
public int getTot() {
    return tot;
}
/**
 * @param tot the tot to set
 */
public void setTot(int tot) {
    this.tot = tot;
}
/**
 * @return the rdate
 */
public String getRdate() {
    return rdate;
}
/**
 * @param rdate the rdate to set
 */
public void setRdate(String rdate) {
    this.rdate = rdate;
}
  


}