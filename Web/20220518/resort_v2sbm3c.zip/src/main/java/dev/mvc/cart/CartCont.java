package dev.mvc.cart;

import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import dev.mvc.categrp.CategrpVO;

@Controller
public class CartCont {
  @Autowired 
  @Qualifier("dev.mvc.cart.CartProc")
  private CartProcInter cartProc;
  
  public CartCont() {
    System.out.println("-> CartCont created.");
  }
 
  // http://localhost:9091/cart/create.do
  /**
   * Ajax 등록 처리
   * INSERT INTO cart(cartno, contentsno, memberno, cnt, rdate)
   * VALUES(cart_seq.nextval, #{contentsno}, #{memberno}, #{cnt}, sysdate)
   * @param categrpVO
   * @return
   */
  @RequestMapping(value="/cart/create.do", method=RequestMethod.POST )
  @ResponseBody
  public String create(HttpSession session,
                            int contentsno) {
    CartVO cartVO = new CartVO();
    cartVO.setContentsno(contentsno);
    
    int memberno = (Integer)session.getAttribute("memberno");
    cartVO.setMemberno(memberno);
    
    cartVO.setCnt(1); // 최초 구매 수량 1개로 지정
    
    int cnt = this.cartProc.create(cartVO); // 등록 처리
    
    JSONObject json = new JSONObject();
    json.put("cnt", cnt);
    
    System.out.println("-> cartCont create: " + json.toString());

    return json.toString();
  }
  
}