package dev.mvc.memo;

import java.util.HashMap;
import java.util.List;



public interface MemoDAOInter {
    /**
     * 등록
     * @param memoVO
     * @return
     */
    public int create(MemoVO memoVO);
    
    /**
     * sw 수정
     * @param memoVO
     * @return
     */
   // public int update_sw(MemoVO memoVO);
    
    /**
     * 검색 레코드 갯수
     * @param hashMap
     * @return
     */
    public int search_count(HashMap<String, Object> hashMap);
    
    /**
     * 검색 + 페이징 목록
     * @param map
     * @return
     */
    public List<MemoVO> list(HashMap<String, Object> map);
    
    /**
     * 조회
     * @param memono
     * @return
     */
    public MemoVO read(int memono);
    /**
     * 텍스트 정보 수정
     * @param memoVO
     * @return
     */
    public int update_text(MemoVO memoVO);
    /**
     * 파일 정보 수정
     * @param memoVO
     * @return
     */
    public int update_file(MemoVO memoVO);
    /**
     * 삭제
     * @param memono
     * @return
     */
    public int delete(int memono);
    
}
