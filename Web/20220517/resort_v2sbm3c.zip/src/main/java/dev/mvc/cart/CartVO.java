package dev.mvc.cart;

/*
  cartno                        NUMBER(10) NOT NULL PRIMARY KEY,
  contentsno                 NUMBER(10) NULL ,
  memberno                 NUMBER(10) NOT NULL,
  cnt                            NUMBER(10) DEFAULT 0 NOT NULL,
  tot                            NUMBER(10) DEFAULT 0 NOT NULL,
  rdate                          DATE NOT NULL,
  
  SELECT t.cartno, c.contentsno, c.title, c.thumb1, c.price, c.dc, c.saleprice, c.point, t.memberno, t.cnt, t.tot, t.rdate 
 */
public class CartVO {
  /** 쇼핑 카트 번호 */
  private int cartno;
  /** 컨텐츠 번호 */
  private int contentsno;
  /** 제목 */
  private String title = "";
  /** 메인 이미지 preview */
  private String thumb1 = "";
  /** 정가 */
  private int price;
  /** 할인률 */
  private int dc;
  /** 판매가 */
  private int saleprice;
  /** 포인트 */
  private int point;
  /** 회원 번호 */
  private int memberno;
  /** 수량 */
  private int cnt;
  /** 금액 = 판매가 x 수량 */
  private int tot;
  /** 등록일 */
  private String rdate;
  


}