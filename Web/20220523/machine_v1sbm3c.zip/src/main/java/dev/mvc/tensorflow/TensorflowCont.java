package dev.mvc.tensorflow;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class TensorflowCont {
  public TensorflowCont() {
    System.out.println("-> TensorflowCont created.");
  }

  // http://localhost:9091/tensorflow/country.do
  @RequestMapping(value = {"/tensorflow/country.do"}, method = RequestMethod.GET)
  public ModelAndView country() {
    ModelAndView mav = new ModelAndView();
    mav.setViewName("/tensorflow/country");  // /WEB-INF/views/tensorflow/country.jsp
    
    return mav;
  }
  
  // http://localhost:9091/tensorflow/wine.do
  @RequestMapping(value = {"/tensorflow/wine.do"}, method = RequestMethod.GET)
  public ModelAndView wine() {
    ModelAndView mav = new ModelAndView();
    mav.setViewName("/tensorflow/wine");  // /WEB-INF/views/tensorflow/wine.jsp
    
    return mav;
  }
  
  
  // http://localhost:9091/tensorflow/iris.do
  @RequestMapping(value = {"/tensorflow/iris.do"}, method = RequestMethod.GET)
  public ModelAndView iris() {
    ModelAndView mav = new ModelAndView();
    mav.setViewName("/tensorflow/iris");  // /WEB-INF/views/tensorflow/iris.jsp
    
    return mav;
  }
  
  // http://localhost:9091/tensorflow/recommend_book/start.do
  @RequestMapping(value = {"/tensorflow/recommend_book/start.do"}, method = RequestMethod.GET)
  public ModelAndView start() {
    ModelAndView mav = new ModelAndView();
    mav.setViewName("/tensorflow/recommend_book/start");  // /WEB-INF/views/tensorflow/recommend_book/start.jsp
    
    return mav;
  }

  // http://localhost:9091/tensorflow/recommend_book/form1.do
  @RequestMapping(value = {"/tensorflow/recommend_book/form1.do"}, method = RequestMethod.GET)
  public ModelAndView form1() {
    ModelAndView mav = new ModelAndView();
    mav.setViewName("/tensorflow/recommend_book/form1");  // /WEB-INF/views/tensorflow/recommend_book/form1.jsp
    
    return mav;
  }

  // http://localhost:9091/tensorflow/recommend_book/form2.do
  @RequestMapping(value = {"/tensorflow/recommend_book/form2.do"}, method = RequestMethod.GET)
  public ModelAndView form2() {
    ModelAndView mav = new ModelAndView();
    mav.setViewName("/tensorflow/recommend_book/form2");  // /WEB-INF/views/tensorflow/recommend_book/form2.jsp
    
    return mav;
  }

  // http://localhost:9091/tensorflow/recommend_book/form3.do
  @RequestMapping(value = {"/tensorflow/recommend_book/form3.do"}, method = RequestMethod.GET)
  public ModelAndView form3() {
    ModelAndView mav = new ModelAndView();
    mav.setViewName("/tensorflow/recommend_book/form3");  // /WEB-INF/views/tensorflow/recommend_book/form3.jsp
    
    return mav;
  }
  
  // http://localhost:9091/tensorflow/recommend_book/end.do
  @RequestMapping(value = {"/tensorflow/recommend_book/end.do"}, method = RequestMethod.GET)
  public ModelAndView end() {
    ModelAndView mav = new ModelAndView();
    mav.setViewName("/tensorflow/recommend_book/end");  // /WEB-INF/views/tensorflow/recommend_book/end.jsp
    
    return mav;
  }
}