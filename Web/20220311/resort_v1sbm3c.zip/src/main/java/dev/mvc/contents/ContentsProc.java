package dev.mvc.contents;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import dev.mvc.tool.Tool;

@Component("dev.mvc.contents.ContentsProc")
  public class ContentsProc implements ContentsProcInter {
    @Autowired
    private ContentsDAOInter contentsDAO;

    @Override
    public int create(ContentsVO contentsVO) {
      int cnt=this.contentsDAO.create(contentsVO);
      return cnt;
    }
    /**
     * 조회
     */
    @Override
    public ContentsVO read(int contentsno) {
      ContentsVO contentsVO = this.contentsDAO.read(contentsno);
      
      String title = contentsVO.getTitle();
      String content = contentsVO.getContent();
      
      title = Tool.convertChar(title);  // 특수 문자 처리
      content = Tool.convertChar(content); 
      
      contentsVO.setTitle(title);
      contentsVO.setContent(content);  
      
      long size1 = contentsVO.getSize1();
      contentsVO.setSize1_label(Tool.unit(size1));
      
      return contentsVO;
    }
    
    @Override
    public int product_update(ContentsVO contentsVO) {
      int cnt = this.contentsDAO.product_update(contentsVO);
      return cnt;
    }
    
    @Override
    public List<ContentsVO> list_by_cateno(int cateno) {
      List<ContentsVO> list = this.contentsDAO.list_by_cateno(cateno);
      
      for (ContentsVO contentsVO : list) {
          String content = contentsVO.getContent();

          if (content.length() > 160) { // 160 초과이면 160자만 선택
              content = content.substring(0, 160) + "...";
              contentsVO.setContent(content);
          }

          String title = contentsVO.getTitle();

          title = Tool.convertChar(title); // 특수 문자 처리
          content = Tool.convertChar(content);

          contentsVO.setTitle(title);
          contentsVO.setContent(content);
      }
      
      return list;
    }
    
    @Override
    public List<ContentsVO> list_by_cateno_search(HashMap<String, Object> hashMap) {
      List<ContentsVO> list = contentsDAO.list_by_cateno_search(hashMap);
      
      for (ContentsVO contentsVO : list) { // 내용이 160자 이상이면 160자만 선택
        String content = contentsVO.getContent();
        if (content.length() > 160) {
          content = content.substring(0, 160) + "...";
          contentsVO.setContent(content);
        }
      }
      
      return list;
    }

    @Override
    public int search_count(HashMap<String, Object> hashMap) {
      int count = contentsDAO.search_count(hashMap);
      return count;
    }
}