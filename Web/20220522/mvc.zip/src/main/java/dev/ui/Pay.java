package dev.ui;

public enum Pay {
  주문,
  배송,
  결재,
  반품,
  환불,
  기타
}