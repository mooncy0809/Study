package dev.mvc.ajax;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class JSONContObj {
  public JSONContObj() {
    System.out.println("-> JSONContObj created.");
  }

  /**
   * 객체 출력
   * http://localhost:9091/javascript/json/object3.do
   * @return
   */
  @RequestMapping(value = "/javascript/json/object3.do", method = RequestMethod.GET)
  public ModelAndView object3() {
    ModelAndView mav = new ModelAndView();
    mav.setViewName("/javascript/json/object3");  // /WEB-INF/views/javascript/json/object3.jsp

    return mav;
  }

  /**
   * JSON 객체 읽기 3
   * http://localhost:9091/javascript/json/object3_json.do
   * {
   *   "product":{"price":400000,"display":"7 inch","name":"Android Phone"},
   *   "code":"A001"
   * }
   * @return
   */
  @ResponseBody
  @RequestMapping(value = "/javascript/json/object3_json.do", method = RequestMethod.GET)
  public String object3_json() {
    try {
      Thread.sleep(3000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    
    /*
    {
      "code":"A001",
      "product":{
                    "name":"Android Phone",
                    "price":400000,
                    "display":"7 inch"
                    }
    }
    */
    JSONObject parent = new JSONObject(); // 부모 객체
    parent.put("code", "A001");

    JSONObject product = new JSONObject(); // 자식 개체
    product.put("name", "Android Phone");
    product.put("price", 400000);
    product.put("display", "7 inch");

    parent.put("product", product); // 부모 json 객체에 자식 json 객체를 추가

    return parent.toString();
  }

}
