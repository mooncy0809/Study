package dev.mvc.ajax;

import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class AjaxContCycle {
  public AjaxContCycle() {
    System.out.println("-> AjaxContCycle created.");
  }
  
  /**
   * http://localhost:9091/cycle/interval_ajax.do
   * {"cnt":1}
   * @return
   */
  @ResponseBody
  @RequestMapping(value = "/cycle/interval_ajax.do", method = RequestMethod.GET)
  public String interval_ajax() {
    try {
      Thread.sleep(3000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    
    JSONObject json = new JSONObject();
    json.put("cnt", 1);
    
    return json.toString();   
  }
}