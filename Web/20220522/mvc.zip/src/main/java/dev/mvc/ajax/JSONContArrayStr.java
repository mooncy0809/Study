package dev.mvc.ajax;

import org.json.JSONArray;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class JSONContArrayStr {
  public JSONContArrayStr() {
    System.out.println("-> JSONContArrayStr created.");
  }
  
  /**
   * 배열
   * http://localhost:9091/javascript/json/array_str.do
   * @return
   */
  @RequestMapping(value = "/javascript/json/array_str.do", method = RequestMethod.GET)
  public ModelAndView array_str() {
    ModelAndView mav = new ModelAndView();
    mav.setViewName("/javascript/json/array_str");  // /WEB-INF/views/javascript/json/array_str.jsp

    return mav;
  }
  
  /**
   * JSON 배열 읽기 
   * http://localhost:9091/javascript/json/array_str_json.do
   * ["01.jpg","02.jpg","03.jpg"]
   * @return
   */
  @ResponseBody
  @RequestMapping(value = "/javascript/json/array_str_json.do", method = RequestMethod.GET)
  public String array_str_json() {
    try {
      Thread.sleep(3000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    
    JSONArray list = new JSONArray(); // 배열
    
    list.put("01.jpg");  // 배열에 객체 추가
    list.put("02.jpg");  // 배열에 객체 추가
    list.put("03.jpg");  // 배열에 객체 추가

    return list.toString();
  }
}