package dev.mvc.burl;

public class Urlgrp_UrlVO {
    /** 즐겨찾기 그룹 번호 */
    private int r_urlgrpno;
    /**  즐겨찾기 이름 */
    private String r_title;
    
    
    /** 즐겨찾기 번호 */
    private int urlno;  
    /** 즐겨찾기 그룹 번호 */
    private int urlgrpno;
    /** 즐겨찾기 이름 */
    private String title;
    /** 주소 */
    private String url;
    /** 등록일 */
    private String rdate;
    
    public Urlgrp_UrlVO() {
        
    }
    
    /**
     * @return the r_urlgrpno
     */
    public int getR_urlgrpno() {
        return r_urlgrpno;
    }
    /**
     * @param r_urlgrpno the r_urlgrpno to set
     */
    public void setR_urlgrpno(int r_urlgrpno) {
        this.r_urlgrpno = r_urlgrpno;
    }
    /**
     * @return the r_title
     */
    public String getR_title() {
        return r_title;
    }
    /**
     * @param r_title the r_title to set
     */
    public void setR_title(String r_title) {
        this.r_title = r_title;
    }
    /**
     * @return the urlno
     */
    public int getUrlno() {
        return urlno;
    }
    /**
     * @param urlno the urlno to set
     */
    public void setUrlno(int urlno) {
        this.urlno = urlno;
    }
    /**
     * @return the urlgrpno
     */
    public int getUrlgrpno() {
        return urlgrpno;
    }
    /**
     * @param urlgrpno the urlgrpno to set
     */
    public void setUrlgrpno(int urlgrpno) {
        this.urlgrpno = urlgrpno;
    }
    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }
    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }
    /**
     * @return the url
     */
    public String getUrl() {
        return url;
    }
    /**
     * @param url the url to set
     */
    public void setUrl(String url) {
        this.url = url;
    }
    /**
     * @return the rdate
     */
    public String getRdate() {
        return rdate;
    }
    /**
     * @param rdate the rdate to set
     */
    public void setRdate(String rdate) {
        this.rdate = rdate;
    }
    @Override
    public String toString() {
      return "[r_urlgrpno=" + r_urlgrpno + ", r_title=" + r_title + ", urlno=" + urlno + ", urlgrpno="
          + urlgrpno + ", title=" + title +",url="+url+", rdate=" + rdate + "]";
    }
}
