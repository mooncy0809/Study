package dev.mvc.memo;

import org.springframework.web.multipart.MultipartFile;
/*
 *      memono                              NUMBER(10)       NOT NULL        PRIMARY KEY,
        title                               VARCHAR2(300)        NOT NULL,
        content                             CLOB         NOT NULL,
        file1                               VARCHAR2(100)        NULL ,
        file1saved                          VARCHAR2(100)        NULL ,
        thumb1                              VARCHAR2(100)        NULL ,
        size1                               NUMBER(10)       DEFAULT 0       NULL ,
        sw                                  CHAR(1)      DEFAULT 'A'         NULL ,
        rdate                               DATE         NOT NULL
 */
public class MemoVO {
    /** 메모 번호 */
    private int memono;
    /** 제목 */
    private String title = "";
    /** 내용 */
    private String content = "";
    /** 메인 이미지 */
    private String file1 = "";
    /** 실제 저장된 메인 이미지 */
    private String file1saved = "";  
    /** 메인 이미지 preview */
    private String thumb1 = "";
    /** 메인 이미지 크기 */
    private long size1;
    /** 진행 상태 */
    private String sw;
    /** 등록 날짜 */
    private String rdate = "";
    /**
     * 파일 크기 단위 출력
     */
    private String size1_label="";
    /**
     * 이미지 파일
     * <input type='file' class="form-control" name='file1MF' id='file1MF' value='' placeholder="파일 선택">
     */
    private MultipartFile file1MF;
    
    public MemoVO() {
        
    }
    
    /**
     * @return the file1MF
     */
    public MultipartFile getFile1MF() {
        return file1MF;
    }
    /**
     * @param file1mf the file1MF to set
     */
    public void setFile1MF(MultipartFile file1mf) {
        file1MF = file1mf;
    }
    /**
     * @return the memono
     */
    public int getMemono() {
        return memono;
    }
    /**
     * @param memono the memono to set
     */
    public void setMemono(int memono) {
        this.memono = memono;
    }
    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }
    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }
    /**
     * @return the content
     */
    public String getContent() {
        return content;
    }
    /**
     * @param content the content to set
     */
    public void setContent(String content) {
        this.content = content;
    }
    /**
     * @return the file1
     */
    public String getFile1() {
        return file1;
    }
    /**
     * @param file1 the file1 to set
     */
    public void setFile1(String file1) {
        this.file1 = file1;
    }
    /**
     * @return the file1saved
     */
    public String getFile1saved() {
        return file1saved;
    }
    /**
     * @param file1saved the file1saved to set
     */
    public void setFile1saved(String file1saved) {
        this.file1saved = file1saved;
    }
    /**
     * @return the thumb1
     */
    public String getThumb1() {
        return thumb1;
    }
    /**
     * @param thumb1 the thumb1 to set
     */
    public void setThumb1(String thumb1) {
        this.thumb1 = thumb1;
    }
    /**
     * @return the size1
     */
    public long getSize1() {
        return size1;
    }
    /**
     * @param size1 the size1 to set
     */
    public void setSize1(long size1) {
        this.size1 = size1;
    }
    /**
     * @return the sw
     */
    public String getSw() {
        return sw;
    }
    /**
     * @param sw the sw to set
     */
    public void setSw(String sw) {
        this.sw = sw;
    }
    /**
     * @return the rdate
     */
    public String getRdate() {
        return rdate;
    }
    /**
     * @param rdate the rdate to set
     */
    public void setRdate(String rdate) {
        this.rdate = rdate;
    }
    /**
     * @return the size1_label
     */
    public String getSize1_label() {
        return size1_label;
    }
    /**
     * @param size1_label the size1_label to set
     */
    public void setSize1_label(String size1_label) {
        this.size1_label = size1_label;
    }

}
