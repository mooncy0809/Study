package dev.mvc.bcate;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import dev.mvc.bcategrp.BcategrpProcInter;
import dev.mvc.bcategrp.BcategrpVO;

@Controller
public class BcateCont {
    @Autowired
    @Qualifier("dev.mvc.bcategrp.BcategrpProc")
    private BcategrpProcInter bcategrpProc;
    @Autowired
    @Qualifier("dev.mvc.bcate.BcateProc")
    private BcateProcInter bcateProc;

    public BcateCont() {
        System.out.println("-> BcateCont created.");
    }
    
    
    /**
     * 등록폼 http://localhost:9091/bookcate/create.do?bcategrpno=2
     * 
     * @return
     */
    @RequestMapping(value = "/bookcate/create.do", method = RequestMethod.GET)
    public ModelAndView create() {
      ModelAndView mav = new ModelAndView();
      mav.setViewName("/bookcate/create"); // /webapp/WEB-INF/views/bookcate/create.jsp

      return mav;
    }
    
    /**
     * 등록처리
     * BcateVO bcateVO 객체안의 필드들이 <form> 태그에 존재하면 자동으로 setter 호출됨.
     * <form>태그에 존재하는 값들은 BcateVO bcateVO 객체안의 필드에 setter를 이용하여 자동할당됨.
     * http://localhost:9091/bookcate/create.do?bcategrpno=2
     * 자주발생하는 에러
     * Exception: FK 전달이 안됨.
     * Field error in object 'bcateVO' on field 'bcategrpno': rejected value [];
     * codes [typeMismatch.bcateVO.bcategrpno,typeMismatch.bcategrpno,typeMismatch.int,typeMismatch]; 
     * arguments [org.springframework.context.support.DefaultMessageSourceResolvable: codes [bcateVO.bcategrpno,bcategrpno];
     * arguments []; default message [bcategrpno]]; 
     * default message [Failed to convert property value of type 'java.lang.String' to required type 'int' for property 'bcategrpno';
     * nested exception is java.lang.NumberFormatException: For input string: ""]]
     * @return
     */
    @RequestMapping(value = "/bookcate/create.do", method = RequestMethod.POST)
    public ModelAndView create(BcateVO bcateVO) {
      ModelAndView mav = new ModelAndView();

      // System.out.println("-> bcategrpno: " + bcateVO.getBcategrpno());
      
      int cnt = this.bcateProc.create(bcateVO);
      System.out.println("등록 성공");

      mav.addObject("code", "create_success");
      mav.addObject("cnt", cnt);
      mav.addObject("bcategrpno", bcateVO.getBcategrpno());
      mav.addObject("name", bcateVO.getName());
      
      mav.setViewName("/bookcate/msg");
 
      return mav;
    }
    /**
     * 전체 목록
     * http://localhost:9091/bookcate/list_all.do 
     * @return
     */
    @RequestMapping(value="/bookcate/list_all.do", method=RequestMethod.GET )
    public ModelAndView list_all() {
      ModelAndView mav = new ModelAndView();
      
      List<BcateVO> list = this.bcateProc.list_all();
      mav.addObject("list", list); // request.setAttribute("list", list);

      mav.setViewName("/bookcate/list_all"); // /cate/list_all.jsp
      return mav;
    }
    /**
     * 카테고리 그룹별 전체 목록
     * http://localhost:9091/cate/list_by_categrpno.do?categrpno=1 
     * @return
     */
    @RequestMapping(value="/bookcate/list_by_categrpno.do", method=RequestMethod.GET )
    public ModelAndView list_by_categrpno(int bcategrpno) {
      ModelAndView mav = new ModelAndView();
      
      List<BcateVO> list = this.bcateProc.list_by_categrpno(bcategrpno);
      mav.addObject("list", list); // request.setAttribute("list", list);

      BcategrpVO  bcategrpVO = this.bcategrpProc.read(bcategrpno); // 카테고리 그룹 정보
      mav.addObject("bcategrpVO", bcategrpVO); 
      
      mav.setViewName("/bookcate/list_by_categrpno"); // /cate/list_by_categrpno.jsp
      return mav;
    }
    /**
     * Bcategrp + Bcate join, 연결 목록
     * http://localhost:9091/cate/list_all_join.do 
     * @return
     */
    @RequestMapping(value="/bookcate/list_all_join.do", method=RequestMethod.GET )
    public ModelAndView list_all_join() {
      ModelAndView mav = new ModelAndView();
      
      List<Bcategrp_BcateVO> list = this.bcateProc.list_all_join();
      mav.addObject("list", list); // request.setAttribute("list", list);

      mav.setViewName("/bookcate/list_all_join"); // /WEB-INF/views/cate/list_all_join.jsp
      return mav;
    }
    /**
     * 조회 + 수정폼 http://localhost:9091/cate/read_update.do
     * 
     * @return
     */
    @RequestMapping(value = "/bookcate/read_update.do", method = RequestMethod.GET)
    public ModelAndView read_update(int bcateno) {
      // int bcateno = Integer.parseInt(request.getParameter("bcateno"));

      ModelAndView mav = new ModelAndView();
      mav.setViewName("/bookcate/read_update"); // read_update.jsp

      // 카테고리 정보
      BcateVO bcateVO = this.bcateProc.read(bcateno);
      mav.addObject("bcateVO", bcateVO);
      // request.setAttribute("bcateVO", bcateVO);
      
      int bcategrpno = bcateVO.getBcategrpno();
      
      // 카테고리 그룹 정보
      BcategrpVO bcategrpVO = this.bcategrpProc.read(bcategrpno);
      mav.addObject("bcategrpVO", bcategrpVO);

      // 카테고리 목록
      List<BcateVO> list = this.bcateProc.list_by_categrpno(bcategrpno);
      mav.addObject("list", list);

      return mav; // forward
    }
    
    /**
     * 수정 처리
     * 
     * @param bcateVO
     * @return
     */
    @RequestMapping(value = "/bookcate/update.do", method = RequestMethod.POST)
    public ModelAndView update(BcateVO bcateVO) {
      ModelAndView mav = new ModelAndView();

      int cnt = this.bcateProc.update(bcateVO);
      
      if (cnt == 1) {
          mav.addObject("bcategrpno", bcateVO.getBcategrpno());
          mav.setViewName("redirect:/bookcate/list_by_categrpno.do");
      } else {
          mav.addObject("code", "update_fail"); // request에 저장
          mav.addObject("cnt", cnt); // request에 저장
          mav.addObject("bcateno", bcateVO.getBcateno());
          mav.addObject("bcategrpno", bcateVO.getBcategrpno());
          mav.addObject("name", bcateVO.getName());
          mav.addObject("url", "/bookcate/msg");  // /cate/msg -> /cate/msg.jsp로 최종 실행됨.
          
          mav.setViewName("/bookcate/msg"); // 새로고침 문제 해결, request 초기화
          
      }
      
      return mav;
    }
    /**
     * 조회 + 삭제폼 http://localhost:9091/bookcate/read_delete.do
     * 
     * @return
     */
    @RequestMapping(value = "/bookcate/read_delete.do", method = RequestMethod.GET)
    public ModelAndView read_delete(int bcateno) {
      // int bcateno = Integer.parseInt(request.getParameter("bcateno"));
      ModelAndView mav = new ModelAndView();
      mav.setViewName("/bookcate/read_delete"); // read_delete.jsp

      BcateVO bcateVO = this.bcateProc.read(bcateno);
      mav.addObject("bcateVO", bcateVO);
      // request.setAttribute("bcateVO", bcateVO);
      int bcategrpno = bcateVO.getBcategrpno();
      
      BcategrpVO bcategrpVO = this.bcategrpProc.read(bcategrpno);
      mav.addObject("bcategrpVO", bcategrpVO);
      

      List<BcateVO> list = this.bcateProc.list_by_categrpno(bcategrpno);
      mav.addObject("list", list);

      return mav; // forward
    }
    
    /**
     * 삭제 처리
     * 
     * @param bcateVO
     * @return
     */
    @RequestMapping(value = "/bookcate/delete.do", method = RequestMethod.POST)
    public ModelAndView delete(int bcateno) {
      ModelAndView mav = new ModelAndView();
      // 삭제될 레코드 정보를 삭제하기전에 읽음
      BcateVO bcateVO = this.bcateProc.read(bcateno); 
      
      int cnt = this.bcateProc.delete(bcateno);
      
      if (cnt == 1) {
          mav.addObject("bcategrpno", bcateVO.getBcategrpno());
          mav.setViewName("redirect:/bookcate/list_by_categrpno.do");
      } else {
          mav.addObject("code", "delete_fail"); // request에 저장
          mav.addObject("cnt", cnt); // request에 저장
          mav.addObject("bcateno", bcateVO.getBcateno());
          mav.addObject("bcategrpno", bcateVO.getBcategrpno());
          mav.addObject("name", bcateVO.getName());
          mav.addObject("url", "/bookcate/msg");  // /cate/msg -> /cate/msg.jsp로 최종 실행됨.
          
          mav.setViewName("/bookcate/msg"); // /WEB-INF/views/cate/msg.jsp
          
      }
      
      return mav;
    }
}