package dev.mvc.ajax;

import java.text.DecimalFormat;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class PayCont {
  public PayCont() {
    System.out.println("-> PayCont created.");
  }
  
  /**
   * Ajax를 사용하지 않는 급여 조회
   * http://localhost:9091/javascript/ajax/pay.do
   * @return
   */
  @RequestMapping(value = "/javascript/ajax/pay.do", method = RequestMethod.GET)
  public ModelAndView pay_form() {
    ModelAndView mav = new ModelAndView();
    mav.setViewName("/javascript/ajax/pay_form");  // /WEB-INF/views/javascript/ajax/pay_form.jsp

    return mav;
  }
  
  /**
   * Ajax를 사용하지 않는 급여 조회 처리
   * http://localhost:9091/javascript/ajax/pay.do
   * @return
   */
  @RequestMapping(value = "/javascript/ajax/pay.do", method = RequestMethod.POST)
  public ModelAndView pay_proc(String id, String passwd) {
    
    try {
      Thread.sleep(2000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    
    ModelAndView mav = new ModelAndView();
    
    DecimalFormat df = new DecimalFormat("#, ###, ### 원");
    
    if (id.equals("user1") && passwd.equals("1234")) {
      mav.addObject("name", "개발자");
      mav.addObject("basic", df.format(2500000));
      mav.addObject("bonus", df.format(100000));
      mav.addObject("total", df.format(2600000));
      mav.setViewName("/javascript/ajax/pay_proc");  // /WEB-INF/views/javascript/ajax/pay_proc.jsp
      
    } else {
      mav.setViewName("/javascript/ajax/pay_fail");  // /WEB-INF/views/javascript/ajax/pay_fail.jsp
    }

    return mav;
  }
  
  /**
   * Ajax를 사용하는 급여 조회
   * http://localhost:9091/javascript/ajax/pay_ajax.do
   * @return
   */
  @RequestMapping(value = "/javascript/ajax/pay_ajax.do", method = RequestMethod.GET)
  public ModelAndView pay_ajax() {
    ModelAndView mav = new ModelAndView();
    mav.setViewName("/javascript/ajax/pay_ajax");  // /WEB-INF/views/javascript/ajax/pay_ajax.jsp

    return mav;
  }
  
  /**
   * Ajax를 사용하는 급여 조회 처리
   * http://localhost:9091/ajax/pay_ajax.do
   * @return html 문자열
   */
  @ResponseBody
  @RequestMapping(value = "/javascript/ajax/pay_ajax.do", method = RequestMethod.POST)
  public String pay_ajax(String id, String passwd) {
    // System.out.println("-> " + "/javascript/ajax/pay_ajax.do called.");
    
    try {
      Thread.sleep(3000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    
    DecimalFormat df = new DecimalFormat("#, ###, ### 원");
    
    String html = "";
    if (id.equals("user1") && passwd.equals("1234")) {
      html = "<DIV style='color: #0000FF; text-align: left; width: 200px; margin: 0px auto;'>";
      html += "성명: 개발자" + "<BR>";
      html += "아이디: " + id + "<BR>";
      html += "본봉: " + df.format(2500000) + "<BR>";
      html += "수당: " + df.format(100000) + "<BR>";
      html += "합계: " + df.format(2600000) + "<BR>";
      html += "</DIV>";
    } else {
      html = "<div style='color: red;'>아이디와 패스워드가 일치하지 않습니다. <br> 다시 시도해주세요.</div>";
    }

    return html;
  }
  
}