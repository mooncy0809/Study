package dev.el;

public class NullTest {
    public static void main(String[] args) {
        String season = null;
        System.out.println(season.toLowerCase());
    }
    
}
