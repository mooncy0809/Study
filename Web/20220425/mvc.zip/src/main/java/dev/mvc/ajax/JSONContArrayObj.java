package dev.mvc.ajax;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class JSONContArrayObj {
  public JSONContArrayObj() {
    System.out.println("-> JSONContArrayObj created.");
  }
  
  /**
   * 배열
   * http://localhost:9091/javascript/json/array_obj.do
   * @return
   */
  @RequestMapping(value = "/javascript/json/array_obj.do", method = RequestMethod.GET)
  public ModelAndView array_obj() {
    ModelAndView mav = new ModelAndView();
    mav.setViewName("/javascript/json/array_obj");  // /WEB-INF/views/javascript/json/array_obj.jsp

    return mav;
  }
  
  /**
   * JSON 배열 읽기 
   * http://localhost:9091/javascript/json/array_obj_json.do
   * [
   *   {"data":90,"web":80,"name":"가길순","id":"user1"},
   *   {"data":70,"web":75,"name":"나길순","id":"user2"},
   *   {"data":95,"web":100,"name":"아로미","id":"user3"}
   * ]
   * @return
   */
  @ResponseBody
  @RequestMapping(value = "/javascript/json/array_obj_json.do", method = RequestMethod.GET)
  public String array_obj_json() {
    try {
      Thread.sleep(3000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    
    JSONArray list = new JSONArray(); // 배열

    JSONObject json = new JSONObject(); // 배열에 추가할 객체
    json.put("name", "가길순");
    json.put("id", "user1");
    json.put("web", 80);
    json.put("data", 90);
    
    list.put(json);  // 배열에 객체 추가

    json = new JSONObject();
    json.put("name", "나길순");
    json.put("id", "user2");
    json.put("web", 75);
    json.put("data", 70);
    
    list.put(json);  // 배열에 객체 추가

    json = new JSONObject();
    json.put("name", "아로미");
    json.put("id", "user3");
    json.put("web", 100);
    json.put("data", 95);
    
    list.put(json);  // 배열에 객체 추가

    // [
    //    {"data":90,"web":80,"name":"가길순","id":"user1"},
    //    {"data":70,"web":75,"name":"나길순","id":"user2"},
    //    {"data":95,"web":100,"name":"아로미","id":"user3"}
    // ]
    
    return list.toString();
  }
}