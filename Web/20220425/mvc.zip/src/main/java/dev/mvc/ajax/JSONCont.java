package dev.mvc.ajax;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class JSONCont {
  
  public JSONCont() {
    System.out.println("-> JSONCont created.");  
    
  }
  
  /**
   * Ajax를 사용하지 않는 급여 조회
   * http://localhost:9091/javascript/json/object1.do
   * @return
   */
  @RequestMapping(value = "/javascript/json/object1.do", method = RequestMethod.GET)
  public ModelAndView pay_form() {
    ModelAndView mav = new ModelAndView();
    mav.setViewName("/javascript/json/object1");  // /WEB-INF/views/javascript/json/object1.jsp

    return mav;
  }
  
  /**
   * JSON 객체 읽기
   * http://localhost:9091/json/one.do
   * {"name": "아로미", "id": "user2", "web": 100, "data": 90}
   * @return
   */
  @ResponseBody
  @RequestMapping(value = "/json/one.do", method = RequestMethod.GET)
  public String object1() {
    try {
      Thread.sleep(3000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    
    String json = "";
    json = "{\"name\": \"아로미\", \"id\": \"user2\", \"web\": 100, \"data\": 90}";
    
    return json;    
  }
  
  /**
   * Ajax를 사용하지 않는 급여 조회
   * http://localhost:9091/javascript/json/object2.do
   * @return
   */
  @RequestMapping(value = "/javascript/json/object2.do", method = RequestMethod.GET)
  public ModelAndView object2() {
    ModelAndView mav = new ModelAndView();
    mav.setViewName("/javascript/json/object2");  // /WEB-INF/views/javascript/json/object2.jsp

    return mav;
  }
  
  /**
   * JSON 객체 읽기 2
   * http://localhost:9091/javascript/json/object2_json.do
   * {"data":90,"web":100,"name":"아로미","id":"user2"}
   * @return
   */
  @ResponseBody
  @RequestMapping(value = "/javascript/json/object2_json.do", method = RequestMethod.GET)
  public String object2_json() {
    try {
      Thread.sleep(3000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    
    JSONObject json = new JSONObject();
    json.put("name", "아로미");  // 키, 값
    json.put("id", "user2");
    json.put("web", 100);
    json.put("data", 90);
    
    return json.toString();
  }
 
}