package dev.boot.mvc;

public class YoutubeTest {

    public static String youtube(String url, int width, int height) {
        int width1 = url.indexOf("\"");
        int width2 = url.indexOf("\"",width1+1);
        int height1 = url.indexOf("\"",width2+1);
        int height2 = url.indexOf("\"",height1+1);

        url = url.substring(0,width1+1)+"width"+url.substring(width2, height1+1)+"height"+url.substring(height2);
        
        return url;
    }
    public static void main(String[] args) {
        String url = "<iframe width=\"950\" height=\"534\" src=\"https://www.youtube.com/embed/yNvjituGDLQ\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>";
        String[] url_split = url.split(" "); //문자열을 공백으로 분리
    //    for(int i=0;i<url_split.length;i++) {
    //        System.out.println(url_split[i]);
    //    }
        
    //    System.out.println(url_split[1]);
    //    System.out.println(url_split[2]);
        
        int width1 = url.indexOf("\"");
        System.out.println(width1);
        
        int width2 = url.indexOf("\"",width1+1);
        System.out.println(width2);
        
        int height1 = url.indexOf("\"",width2+1);
        System.out.println(height1);
        
        int height2 = url.indexOf("\"",height1+1);
        System.out.println(height2);
        
        System.out.print(url.substring(0, width1 +1));
        System.out.print(238);
        System.out.print(url.substring(width2, height1+1));
        System.out.print(134);
        System.out.print(url.substring(height2));
        url = url.substring(0,width1+1)+"238"+url.substring(width2, height1+1)+"134"+url.substring(height2);
        System.out.println();
        System.out.println(url);
        
        System.out.println("final test");
        System.out.print(youtube(url,200,100));
        System.out.print(youtube(url,300,200));
        System.out.print(youtube(url,400,300));

    }

}
