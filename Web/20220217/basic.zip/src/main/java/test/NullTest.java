package test;

public class NullTest {

  public static void main(String[] args) {
    String url = null;
    System.out.println(url);
    // System.out.println(url.toLowerCase()); //메소드 호출 못함
    //  java.lang.NullPointerException

    if (url == null) {
      System.out.println("url은 메모리를 할당받지 못함");
    }
    
    url = ""; //문자열 값은 없지만 메소드 호출 가능
    if (url.length() == 0 || url.equals("")) {
      System.out.println("값이 없음: " + url);
    }
    System.out.println(url.toLowerCase());

  }

}