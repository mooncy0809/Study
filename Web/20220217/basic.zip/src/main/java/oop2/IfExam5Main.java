package oop2;

public class IfExam5Main {

    public static void main(String[] args) {
        IfExam5 ifExam5 = new IfExam5();
        
        String ret = ifExam5.process(0);
        System.out.println(ret);
        
        ret = ifExam5.process(6);
        System.out.println(ret);
        
        ret = ifExam5.process(11);
        System.out.println(ret);
        
        ret = ifExam5.process(16);
        System.out.println(ret);

    }

}


