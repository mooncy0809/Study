package oop2;

public class IFExam2Main {
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        IfExam2 ifExam = new IfExam2();
        
        String ret = ifExam.process(1);
        System.out.println(ret);
        
        ret = ifExam.process(2);
        System.out.println(ret);
        
        ret = ifExam.process(3);
        System.out.println(ret);
        
        ret = ifExam.process(4);
        System.out.println(ret);
    
        ret = ifExam.process(5);
        System.out.println(ret);
    }
}
