package dev.mvc.burl;

import java.util.List;

public interface UrlProcInter {
    /**
     * 등록
     * @param urlVO
     * @return 등록된 갯수
     */
    public int create(UrlVO urlVO);
    
    /**
     *  전체 목록
     * @return
     */
    public List<UrlVO> list_all();  
    
    /**
     *  urlgrpno별 목록
     * @return
     */
    public List<UrlVO> list_by_urlgrpno(int urlgrpno);   
    
    /**
     * Urlgrp + Url join, 연결 목록
     * @return
     */
    public List<Urlgrp_UrlVO> list_all_join();  
    /**
     * 조회, 수정폼
     * @param urlno 카테고리 번호, PK
     * @return
     */
    public UrlVO read(int urlno);
    
    /**
     * 수정 처리
     * @param urlVO
     * @return 수정된 레코드 갯수
     */
    public int update(UrlVO urlVO);
    
    /**
     * 삭제 처리 
     * @param cateno
     * @return 삭제된 레코드 갯수
     */
    public int delete(int urlno);
}
