package dev.mvc.burlgrp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class BurlgrpCont {
    @Autowired
    @Qualifier("dev.mvc.burlgrp.BurlgrpProc")
    private BurlgrpProcInter burlgrpProc;

    public BurlgrpCont() {
        System.out.println("-> BurlgrpCont created.");
    }

    // http://localhost:9091/burlgrp/create.do
    /**
     * 등록 폼
     * 
     * @return
     */
    @RequestMapping(value = "/burlgrp/create.do", method = RequestMethod.GET)
    public ModelAndView create() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("/burlgrp/create"); // webapp/WEB-INF/views/burlgrp/create.jsp

        return mav; // forward
    }

    // http://localhost:9091/burlgrp/create.do
    /**
     * 등록 처리
     * BurlgrpVO burlgrpVO 객체안의 필드들이 <form> 태그에 존재하면 자동으로 setter 호출됨. 
     * <form> 태그에 존재하는 값들은 BurlgrpVO burlgrpVO 객체안의 필드에 setter를 이용하여 자동 할당됨. 
     * @param burlgrpVO
     * @return
     */
    @RequestMapping(value = "/burlgrp/create.do", method = RequestMethod.POST)
    public ModelAndView create(BurlgrpVO burlgrpVO) { 

        ModelAndView mav = new ModelAndView();

        int cnt = this.burlgrpProc.create(burlgrpVO); // 등록 처리
        // cnt = 0; // error test
        
        mav.addObject("cnt", cnt);
       
        if (cnt == 1) {
            // System.out.println("등록 성공");
            
            mav.addObject("code", "create_success"); // request에 저장, request.setAttribute("code", "create_success")
            mav.setViewName("/burlgrp/msg"); // /WEB-INF/views/burlgrp/msg.jsp
            
            // response.sendRedirect("/burlgrp/list.do");
            // mav.setViewName("redirect:/burlgrp/list.do");
        } else {
            mav.addObject("code", "create_fail"); 
            mav.setViewName("/burlgrp/msg"); 
        }

        return mav; // forward
    }
    @RequestMapping(value="/burlgrp/list.do", method=RequestMethod.GET )
    public ModelAndView list() {
      ModelAndView mav = new ModelAndView();
      
      List<BurlgrpVO> list = this.burlgrpProc.list_urlgrpno_asc();
      mav.addObject("list", list); // request.setAttribute("list", list);

      mav.setViewName("/burlgrp/list"); // /webapp/WEB-INF/views/burlgrp/list.jsp
      return mav;
    }
 // http://localhost:9091/burlgrp/read_update.do?urlgrpno=1
    /**
     * 조회 + 수정폼
     * @param urlgrpno 조회할 카테고리 번호
     * @return
     */
    @RequestMapping(value="/burlgrp/read_update.do", method=RequestMethod.GET )
    public ModelAndView read_update(int urlgrpno) {
      // request.setAttribute("urlgrpno", int urlgrpno) 작동 안됨.
      
      ModelAndView mav = new ModelAndView();
      
      BurlgrpVO burlgrpVO = this.burlgrpProc.read(urlgrpno);
      mav.addObject("burlgrpVO", burlgrpVO);  // request 객체에 저장
      
      List<BurlgrpVO> list = this.burlgrpProc.list_urlgrpno_asc();
      mav.addObject("list", list);  // request 객체에 저장

      mav.setViewName("/burlgrp/read_update"); // /WEB-INF/views/burlgrp/read_update.jsp 
      return mav; // forward
    }
    
 // http://localhost:9091/burlgrp/update.do
    /**
     * 수정 처리
     * 
     * @param burlgrpVO
     * @return
     */
    @RequestMapping(value = "/burlgrp/update.do", method = RequestMethod.POST)
    public ModelAndView update(BurlgrpVO burlgrpVO) {
        // CategrpVO categrpVO <FORM> 태그의 값으로 자동 생성됨.
        // request.setAttribute("categrpVO", categrpVO); 자동 실행

        ModelAndView mav = new ModelAndView();

        int cnt = this.burlgrpProc.update(burlgrpVO);
        mav.addObject("cnt", cnt); // request에 저장

        // cnt = 0; // error test
        if (cnt == 1) {
            // System.out.println("수정 성공");
            // response.sendRedirect("/categrp/list.do");
            mav.setViewName("redirect:/burlgrp/list.do");
        } else {
            mav.addObject("code", "update"); // request에 저장, request.setAttribute("code", "update")
            mav.setViewName("/burlgrp/msg"); // /WEB-INF/views/categrp/msg.jsp
        }

        return mav;
    }
    
 // http://localhost:9091/categrp/read_delete.do
    /**
     * 조회 + 삭제폼
     * @param urlgrpno 조회할 카테고리 번호
     * @return
     */
    @RequestMapping(value="/burlgrp/read_delete.do", method=RequestMethod.GET )
    public ModelAndView read_delete(int urlgrpno) {
      ModelAndView mav = new ModelAndView();
      
      BurlgrpVO burlgrpVO = this.burlgrpProc.read(urlgrpno); // 삭제할 자료 읽기
      mav.addObject("burlgrpVO", burlgrpVO);  // request 객체에 저장
      
      List<BurlgrpVO> list = this.burlgrpProc.list_urlgrpno_asc();
      mav.addObject("list", list);  // request 객체에 저장

      mav.setViewName("/burlgrp/read_delete"); // read_delete.jsp
      return mav;
    }
    
    /**
     * 삭제
     * @param urlgrpno 조회할 카테고리 번호
     * @return
     */
    @RequestMapping(value="/burlgrp/delete.do", method=RequestMethod.POST )
    public ModelAndView delete(int urlgrpno) {
      ModelAndView mav = new ModelAndView();
      
      BurlgrpVO burlgrpVO = this.burlgrpProc.read(urlgrpno); // 삭제 정보
      mav.addObject("burlgrpVO", burlgrpVO);  // request 객체에 저장
      
      int cnt = this.burlgrpProc.delete(urlgrpno); // 삭제 처리
      mav.addObject("cnt", cnt);  // request 객체에 저장
      
      mav.setViewName("/burlgrp/delete_msg"); // delete_msg.jsp

      return mav;
    }
    
    /**
     * 출력 모드의 변경
     * @param burlgrpVO
     * @return
     */
    @RequestMapping(value="/burlgrp/update_visible.do", 
        method=RequestMethod.GET )
    public ModelAndView update_visible(BurlgrpVO burlgrpVO) {
      ModelAndView mav = new ModelAndView();
      
      int cnt = this.burlgrpProc.update_visible(burlgrpVO);
      
      mav.setViewName("redirect:/burlgrp/list.do"); // request 객체 전달 안됨. 
      
      return mav;
    }  
}