package dev.mvc.byou;

public class Ytgrp_YouVO {
    /** 즐겨찾기 그룹 번호 */
    private int r_ytgrpno;
    /**  즐겨찾기 이름 */
    private String r_title;
    
    
    /** 즐겨찾기 번호 */
    private int youno;  
    /** 즐겨찾기 그룹 번호 */
    private int ytgrpno;
    /** 즐겨찾기 이름 */
    private String title;
    /** 주소 */
    private String url;
    /** 등록일 */
    private String rdate;
    
    public Ytgrp_YouVO() {
        
    }
    /**
     * @return the r_ytgrpno
     */
    public int getR_ytgrpno() {
        return r_ytgrpno;
    }
    /**
     * @param r_ytgrpno the r_ytgrpno to set
     */
    public void setR_ytgrpno(int r_ytgrpno) {
        this.r_ytgrpno = r_ytgrpno;
    }
    /**
     * @return the r_title
     */
    public String getR_title() {
        return r_title;
    }
    /**
     * @param r_title the r_title to set
     */
    public void setR_title(String r_title) {
        this.r_title = r_title;
    }
    /**
     * @return the youno
     */
    public int getYouno() {
        return youno;
    }
    /**
     * @param youno the youno to set
     */
    public void setYouno(int youno) {
        this.youno = youno;
    }
    /**
     * @return the ytgrpno
     */
    public int getYtgrpno() {
        return ytgrpno;
    }
    /**
     * @param ytgrpno the ytgrpno to set
     */
    public void setYtgrpno(int ytgrpno) {
        this.ytgrpno = ytgrpno;
    }
    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }
    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }
    /**
     * @return the url
     */
    public String getUrl() {
        return url;
    }
    /**
     * @param url the url to set
     */
    public void setUrl(String url) {
        this.url = url;
    }
    /**
     * @return the rdate
     */
    public String getRdate() {
        return rdate;
    }
    /**
     * @param rdate the rdate to set
     */
    public void setRdate(String rdate) {
        this.rdate = rdate;
    }
    @Override
    public String toString() {
      return "[r_ytgrpno=" + r_ytgrpno + ", r_title=" + r_title + ", youno=" + youno + ", ytgrpno="
          + ytgrpno + ", title=" + title +",url="+url+", rdate=" + rdate + "]";
    }
}
