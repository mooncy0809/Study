package dev.mvc.bcate;

import java.util.List;

public interface BcateProcInter {
  /**
   * 등록
   * @param cateVO
   * @return 등록된 갯수
   */
  public int create(BcateVO bcateVO);
  /**
   *  전체 목록
   * @return
   */
  public List<BcateVO> list_all(); 
  /**
   *  bcategrpno별 목록
   * @return
   */
  public List<BcateVO> list_by_categrpno(int bcategrpno);  
  /**
   * Categrp + Cate join, 연결 목록
   * @return
   */
  public List<Bcategrp_BcateVO> list_all_join();  
  /**
   * 조회, 수정폼
   * @param cateno 카테고리 번호, PK
   * @return
   */
  public BcateVO read(int bcateno);
  
  /**
   * 수정 처리
   * @param cateVO
   * @return
   */
  public int update(BcateVO bcateVO);
  /**
   * 삭제 처리 
   * @param cateno
   * @return
   */
  public int delete(int bcateno);
  
  /**
   * 특정 그룹에 속한 레코드 갯수 산출
   * @param categrpno
   * @return
   */
  public int count_by_bcategrpno(int bcategrpno);
}