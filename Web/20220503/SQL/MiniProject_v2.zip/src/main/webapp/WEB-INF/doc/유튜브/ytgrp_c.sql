/**********************************/
/* Table Name: 유튜브 그룹 */
/**********************************/
DROP TABLE ytgrp CASCADE CONSTRAINTS;

CREATE TABLE ytgrp(
		ytgrpno                       		NUMBER(7)		 NOT NULL		 PRIMARY KEY,
		title                         		VARCHAR2(50)		 NOT NULL,
		cnt                           		NUMBER(10)		 NOT NULL,
		visible                       		VARCHAR2(1)		 DEFAULT 'Y'		 NOT NULL,
		rdate                         		DATE		 NOT NULL
);

COMMENT ON TABLE ytgrp is '유튜브 그룹';
COMMENT ON COLUMN ytgrp.ytgrpno is '유튜브 그룹번호';
COMMENT ON COLUMN ytgrp.title is '주제';
COMMENT ON COLUMN ytgrp.cnt is '관련 자료 수';
COMMENT ON COLUMN ytgrp.visible is '출력모드';
COMMENT ON COLUMN ytgrp.rdate is '날짜';

CREATE SEQUENCE ytgrp_seq
  START WITH 1                -- 시작 번호
  INCREMENT BY 1            -- 증가값
  MAXVALUE 9999999999    -- 최대값: 9999999999 --> NUMBER(10) 대응
  CACHE 2                       -- 2번은 메모리에서만 계산
  NOCYCLE;                      -- 다시 1부터 생성되는 것을 방지



