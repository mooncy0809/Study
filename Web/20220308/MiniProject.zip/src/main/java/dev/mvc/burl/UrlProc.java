package dev.mvc.burl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component("dev.mvc.burl.UrlProc")
public class UrlProc implements UrlProcInter {

  @Autowired
  private UrlDAOInter urlDAO;
 
  public UrlProc() {
    System.out.println("-> UrlProc created");
  }
  
  @Override
  public int create(UrlVO urlVO) {
    int cnt = this.urlDAO.create(urlVO);
    return cnt;
  }
  
  @Override
  public List<UrlVO> list_all() {
      List<UrlVO> list = this.urlDAO.list_all();
      return list;
  }

}