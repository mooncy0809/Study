package dev.mvc.bcontents;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import dev.mvc.tool.Tool;

@Component("dev.mvc.bcontents.BcontentsProc")
  public class BcontentsProc implements BcontentsProcInter {
    @Autowired
    private BcontentsDAOInter bcontentsDAO;

    @Override
    public int create(BcontentsVO bcontentsVO) {
      int cnt=this.bcontentsDAO.create(bcontentsVO);
      return cnt;
    }

}