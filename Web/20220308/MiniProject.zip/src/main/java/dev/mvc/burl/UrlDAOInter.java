package dev.mvc.burl;

import java.util.List;

public interface UrlDAOInter {
    /**
     * 등록
     * @param urlVO
     * @return 등록된 갯수
     */
    public int create(UrlVO urlVO);
    
    /**
     *  전체 목록
     * @return
     */
    public List<UrlVO> list_all();  
}
