package dev.mvc.burl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import dev.mvc.bcate.BcateVO;

@Controller
public class UrlCont {
    @Autowired
    @Qualifier("dev.mvc.burl.UrlProc")  // @Component("dev.mvc.burl.UrlProc")
    private UrlProcInter urlProc;

    public UrlCont() {
        System.out.println("-> UrlCont created.");
    }
    
    /**
     * 등록폼 
     * @return
     */
    @RequestMapping(value = "/burl/create.do", method = RequestMethod.GET)
    public ModelAndView create() {
      ModelAndView mav = new ModelAndView();
      mav.setViewName("/burl/create"); // /webapp/WEB-INF/views/burl/create.jsp

      return mav;
      
    }
    
    /**
     * 등록처리
     * @return
     */
    @RequestMapping(value = "/burl/create.do", method = RequestMethod.POST)
    public ModelAndView create(UrlVO urlVO) {
      ModelAndView mav = new ModelAndView();
      
      int cnt = this.urlProc.create(urlVO);
      System.out.println("등록 성공");

      mav.addObject("code", "create_success");
      mav.addObject("cnt", cnt);
      mav.addObject("urlgrpno", urlVO.getUrlgrpno());
      mav.addObject("title", urlVO.getTitle());
      mav.addObject("url",urlVO.getUrl());
      
      mav.setViewName("/burl/msg");
 
      return mav;
    }
    
    
    /**
     * 전체 목록
     * @return
     */
    @RequestMapping(value="/burl/list_all.do", method=RequestMethod.GET )
    public ModelAndView list_all() {
      ModelAndView mav = new ModelAndView();
      
      List<UrlVO> list = this.urlProc.list_all();
      mav.addObject("list", list); // request.setAttribute("list", list);

      mav.setViewName("/burl/list_all"); // /burl/list_all.jsp
      return mav;
    }

}
