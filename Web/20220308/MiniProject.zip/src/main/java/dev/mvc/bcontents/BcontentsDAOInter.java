package dev.mvc.bcontents;

import java.util.HashMap;
import java.util.List;

public interface BcontentsDAOInter {
  /**
   * 등록
   * @param bcontentsVO
   * @return
   */
  public int create(BcontentsVO bcontentsVO);

}