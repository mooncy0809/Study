package dev.mvc.bcontents;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import dev.mvc.bcate.BcateProcInter;
import dev.mvc.bcate.BcateVO;
import dev.mvc.bcategrp.BcategrpProcInter;
import dev.mvc.bcategrp.BcategrpVO;
//import dev.mvc.member.MemberProcInter;
import dev.mvc.tool.Tool;
import dev.mvc.tool.Upload;

@Controller
public class BcontentsCont {
  @Autowired
  @Qualifier("dev.mvc.bcategrp.BcategrpProc")
  private BcategrpProcInter bcategrpProc;
  
  @Autowired
  @Qualifier("dev.mvc.bcate.BcateProc")
  private BcateProcInter bcateProc;
  
  @Autowired
  @Qualifier("dev.mvc.bcontents.BcontentsProc")
  private BcontentsProcInter bcontentsProc;
  
  public BcontentsCont() {
    System.out.println("-> BcontentsCont created.");
  }

  /**
   * 새로고침 방지
   * @return
   */
  @RequestMapping(value="/bcontents/msg.do", method=RequestMethod.GET)
  public ModelAndView msg(String url){
    ModelAndView mav = new ModelAndView();

    mav.setViewName(url); // forward
    
    return mav; // forward
  }
  
  /**
   * 등록폼 
   * 사전 준비된 레코드: 관리자 1번, bcateno 1번, bcategrpno 1번을 사용하는 경우 테스트 URL
   * http://localhost:9091/bcontents/create.do?bcateno=1&adminno=1 FK 값 명시
   * 
   * @return
   */
  @RequestMapping(value = "/bcontents/create.do", method = RequestMethod.GET)
  public ModelAndView create(int bcateno, int adminno) {
    ModelAndView mav = new ModelAndView();
    
    BcateVO bcateVO = this.bcateProc.read(bcateno);
    BcategrpVO bcategrpVO = this.bcategrpProc.read(bcateVO.getBcategrpno());
    
    mav.addObject("bcateVO", bcateVO);
    mav.addObject("bcategrpVO", bcategrpVO);
    
    mav.setViewName("/bcontents/create"); 

    return mav; // forward
  }
  /**
   * 등록 처리 http://localhost:9091/bcontents/create.do
   * 
   * @return
   */
  @RequestMapping(value = "/bcontents/create.do", method = RequestMethod.POST)
  public ModelAndView create(HttpServletRequest request, BcontentsVO bcontentsVO) {
    ModelAndView mav = new ModelAndView();
    
    // ------------------------------------------------------------------------------
    // 파일 전송 코드 시작
    // ------------------------------------------------------------------------------
    String file1 = "";          // 원본 파일명 image
    String file1saved = "";  // 저장된 파일명, image
    String thumb1 = "";     // preview image

    // 기준 경로 확인
    String user_dir = System.getProperty("user.dir"); // 시스템 제공
    // System.out.println("-> User dir: " + user_dir);
    //  --> User dir: C:\kd1\ws_java\resort_v1sbm3c
    
    // 파일 접근임으로 절대 경로 지정, static 폴더 지정
    // 완성된 경로 C:/kd1/ws_java/resort_v1sbm3c/src/main/resources/static/bcontents/storage
    String upDir =  user_dir + "/src/main/resources/static/contents/storage/"; // 절대 경로
    // System.out.println("-> upDir: " + upDir);
    
    // 전송 파일이 없어도 file1MF 객체가 생성됨.
    // <input type='file' class="form-control" name='file1MF' id='file1MF' 
    //           value='' placeholder="파일 선택">
    MultipartFile mf = bcontentsVO.getFile1MF();
    
    file1 = Tool.getFname(mf.getOriginalFilename()); // 원본 순수 파일명 산출
    // System.out.println("-> file1: " + file1);
    
    long size1 = mf.getSize();  // 파일 크기
    
    if (size1 > 0) { // 파일 크기 체크
      // 파일 저장 후 업로드된 파일명이 리턴됨, spring.jsp, spring_1.jpg...
      file1saved = Upload.saveFileSpring(mf, upDir); 
      
      if (Tool.isImage(file1saved)) { // 이미지인지 검사
        // thumb 이미지 생성후 파일명 리턴됨, width: 200, height: 150
        thumb1 = Tool.preview(upDir, file1saved, 200, 150); 
      }
      
    }    
    
    bcontentsVO.setFile1(file1);
    bcontentsVO.setFile1saved(file1saved);
    bcontentsVO.setThumb1(thumb1);
    bcontentsVO.setSize1(size1);
    // ------------------------------------------------------------------------------
    // 파일 전송 코드 종료
    // ------------------------------------------------------------------------------
    
    // Call By Reference: 메모리 공유, Hashcode 전달
    int cnt = this.bcontentsProc.create(bcontentsVO); 
    
    // ------------------------------------------------------------------------------
    // PK의 return
    // ------------------------------------------------------------------------------
    // System.out.println("--> bcontentsno: " + bcontentsVO.getBcontentsno());
    // mav.addObject("bcontentsno", bcontentsVO.getBcontentsno()); // redirect parameter 적용
    // ------------------------------------------------------------------------------
    
    if (cnt == 1) {
        mav.addObject("code", "create_success");
        // bcateProc.increaseCnt(bcontentsVO.getCateno()); // 글수 증가
    } else {
        mav.addObject("code", "create_fail");
    }
    mav.addObject("cnt", cnt); 
    
    mav.addObject("bcateno", bcontentsVO.getBcateno()); // redirect parameter 적용
    mav.addObject("url", "/bcontents/msg"); // msg.jsp, redirect parameter 적용

    mav.setViewName("redirect:/bcontents/msg.do"); 
    
    return mav; // forward
  }


}