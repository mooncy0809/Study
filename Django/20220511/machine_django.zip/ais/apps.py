from django.apps import AppConfig


class AisConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ais'
