import json

from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
# http://127.0.0.1:8000 --> /ais/templates/index.html
from ais.AI_models.Tensorflow_model import Country


def index(request):
    return render(request, 'index.html')


def country_form(request):
    # 출력 페이지로 보낼 값을 {.....} 블럭에 선언
    # /ais/templates/country_form.html
    return render(request, 'country_form.html', {})


def country_proc(request):
    country = Country()
    drink = request.GET['drink']  # form get
    life = request.GET['life']
    cousin = request.GET['cousin']
    trip = request.GET['trip']
    house = request.GET['house']
    land = request.GET['land']
    data = drink + "," + life + "," + cousin + "," + trip + "," + house + "," + land
    # print('views.py', data)
    result = country.proc(data) # 모델 사용

    result = round(result, 0) # 정수자리까지 반올림

    content = {
                'data': data,
                'result': int(result),
              }
    # 날짜등의 변한 선언: cls=DjangoJSONEncoder
    # return HttpResponse(json.dumps(content, cls=DjangoJSONEncoder), content_type="application/json")
    return HttpResponse(json.dumps(content), content_type="application/json")