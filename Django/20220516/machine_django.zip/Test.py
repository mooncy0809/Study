import tensorflow as tf

print(tf.__version__)
print("Tensorflow 설정 완료")
