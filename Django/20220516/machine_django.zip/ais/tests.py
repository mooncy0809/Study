from django.test import TestCase

# ais.AI_models 패키지에 있는 Tensorflow_model 모듈에서 Recommend_book class import
# import numpy as np
from ais.AI_models.Tensorflow_model import Recommend_book
rb = Recommend_book()

# import ais.AI_models.Tensorflow_model as tm
# rb = tm.Recommend_book()

p = rb.proc('1,1,1') # 개발 관련 도서 추천 필요
print('추천:', p) # 0

p = rb.proc('2,2,2') # 해외 여행 관련 도서 추천 필요
print('추천:', p) # 1

p = rb.proc('3,3,3') # 소설 관련 도서 추천 필요
print('추천:', p) # 2
