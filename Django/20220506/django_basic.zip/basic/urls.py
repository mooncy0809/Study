from django.urls import path
from .views import *

urlpatterns = [
    # 실제 파일 위치: /django_basic/basic/templates/html/title.html
    # http://127.0.0.1:8000/basic/html/title/
    path("html/title/", title, name='title'),  # 폴더명, views.py안의 함수명, 고유한 이름
    # 실제 파일 위치: /django_basic/basic/templates/html/list.html
    # http://127.0.0.1:8000/basic/html/list/
    path("html/list/", list, name='list'),
    path("html/gallery/", gallery, name='gallery'),
    path("js/js01/", js01, name='js01'),
    path("js/js02/", js02, name='js02'),
    path("js/fun01/", fun01, name='fun01'),
    path("js/fun02/", fun02, name='fun02'),
    path("js/array01/", array01, name='array01'),
    path("js/jsinclude/", jsinclude, name='jsinclude'),
]