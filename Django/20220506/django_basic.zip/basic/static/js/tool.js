function wl(str) {
    document.writeln(str + '<br>'); // BODY 태그로 출력됨.
  }

  function add(su1, su2) {
    return su1 + su2;
  }

    // 정규 표현식, 천단위 ',' 출력
  function comma(su) {
    return su.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }