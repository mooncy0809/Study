from django.shortcuts import render

# Create your views here.

def title(request):
    # 실제 파일 위치: /django_basic/basic/templates/html/title.html
    # http://127.0.0.1:8000/basic/html/title/
    return render(request, 'html/title.html')

def list(request):
    # 실제 파일 위치: /django_basic/basic/templates/html/list.html
    # http://127.0.0.1:8000/basic/html/list/
    return render(request, 'html/list.html')

def gallery(request):
    # 실제 파일 위치: /django_basic/basic/templates/html/gallery.html
    # http://127.0.0.1:8000/basic/html/gallery/
    return render(request, 'html/gallery.html')
def js01(request):
    # 실제 파일 위치: /django_basic/basic/templates/js/js01.html
    # http://127.0.0.1:8000/basic/js/js01/
    return render(request, 'js/js01.html')

def js02(request):
    # 실제 파일 위치: /django_basic/basic/templates/js/js02.html
    # http://127.0.0.1:8000/basic/js/js02/
    return render(request, 'js/js02.html')

def fun01(request):
    # 실제 파일 위치: /django_basic/basic/templates/js/fun01.html
    # http://127.0.0.1:8000/basic/js/fun01/
    return render(request, 'js/fun01.html')

def fun02(request):
    # 실제 파일 위치: /django_basic/basic/templates/js/js02.html
    # http://127.0.0.1:8000/basic/js/fun02/
    return render(request, 'js/fun02.html')

def array01(request):
    # 실제 파일 위치: /django_basic/basic/templates/js/array01.html
    # http://127.0.0.1:8000/basic/js/array01/
    return render(request, 'js/array01.html')

def jsinclude(request):
    # 실제 파일 위치: /django_basic/basic/templates/js/jsinclude.html
    # http://127.0.0.1:8000/basic/js/jsinclude/
    return render(request, 'js/jsinclude.html')