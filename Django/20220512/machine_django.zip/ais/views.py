import json

from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
# http://127.0.0.1:8000 --> /ais/templates/index.html
from ais.AI_models.Tensorflow_model import Country
from ais.AI_models.Tensorflow_model import Wine
from ais.AI_models.Tensorflow_model import Iris


def index(request):
    return render(request, 'index.html')


def country_form(request):
    # 출력 페이지로 보낼 값을 {.....} 블럭에 선언
    # /ais/templates/country_form.html
    return render(request, 'country_form.html', {})


def country_proc(request):
    country = Country()
    drink = request.GET['drink']  # form get
    life = request.GET['life']
    cousin = request.GET['cousin']
    trip = request.GET['trip']
    house = request.GET['house']
    land = request.GET['land']
    data = drink + "," + life + "," + cousin + "," + trip + "," + house + "," + land
    # print('views.py', data)
    result = country.proc(data) # 모델 사용

    result = round(result, 0) # 정수자리까지 반올림

    content = {
                'data': data,
                'result': int(result),
              }
    # 날짜등의 변한 선언: cls=DjangoJSONEncoder
    # return HttpResponse(json.dumps(content, cls=DjangoJSONEncoder), content_type="application/json")
    return HttpResponse(json.dumps(content), content_type="application/json")

def wine_form(request):
    # 출력 페이지로 보낼 값을 {.....} 블럭에 선언
    # /ais/templates/wine_form.html
    return render(request, 'wine_form.html', {})

def wine_proc(request):
    print('Wine Ajax 요청 받음')
    data = request.GET['data']

    wine = Wine()
    result = wine.proc(data)

    content = {
                  'data': data,
                  'result': float(result),
                  }
    # 날짜등의 변한 선언: cls=DjangoJSONEncoder
    # return HttpResponse(json.dumps(content, cls=DjangoJSONEncoder), content_type="application/json")
    return HttpResponse(json.dumps(content), content_type="application/json")


def iris_form2(request):
    # 출력 페이지로 보낼 값을 {.....} 블럭에 선언
    # /ais/templates/iris_form2.html
    # return render(request, 'iris_form2.html', {})
    return render(request, 'iris_form2.html', {})

def iris_proc2(request):
    print('Iris Ajax 요청 받음')
    sepal_length = float(request.GET['sepal_length'])
    sepal_width = float(request.GET['sepal_width'])
    petal_length = float(request.GET['petal_length'])
    petal_width = float(request.GET['petal_width'])

    iris = Iris()
    result = iris.proc2(sepal_length, sepal_width, petal_length, petal_width)

    content = {
        'sepal_length':sepal_length ,
        'sepal_width':sepal_width,
        'petal_length':petal_length,
        'petal_width':petal_width,
        'result': int(result),
    }

    # 날짜등의 변한 선언: cls=DjangoJSONEncoder
    # return HttpResponse(json.dumps(content, cls=DjangoJSONEncoder), content_type="application/json")
    return HttpResponse(json.dumps(content), content_type="application/json")
