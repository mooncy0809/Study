/**********************************/
/* Table Name: 유튜브 내용 */
/**********************************/
DROP TABLE you CASCADE CONSTRAINTS;

CREATE TABLE you(
		youno                         		NUMBER(7)		 NOT NULL		 PRIMARY KEY,
		title                         		VARCHAR2(50)		 NOT NULL,
		url                           		VARCHAR2(1000)		 NOT NULL,
		rdate                         		DATE		 NOT NULL,
		ytgrpno                       		NUMBER(7)		 NULL ,
  FOREIGN KEY (ytgrpno) REFERENCES ytgrp (ytgrpno)
);

COMMENT ON TABLE you is '유튜브 내용';
COMMENT ON COLUMN you.youno is '유튜브 번호';
COMMENT ON COLUMN you.title is '제목';
COMMENT ON COLUMN you.url is 'url';
COMMENT ON COLUMN you.rdate is '날짜';
COMMENT ON COLUMN you.ytgrpno is '유튜브 그룹번호';

CREATE SEQUENCE you_seq
  START WITH 1               -- 시작 번호
  INCREMENT BY 1           -- 증가값
  MAXVALUE 9999999999  -- 최대값: 9999999 --> NUMBER(7) 대응
  CACHE 2                       -- 2번은 메모리에서만 계산
  NOCYCLE;                     -- 다시 1부터 생성되는 것을 방지
