/**********************************/
/* Table Name: memo */
/**********************************/
DROP TABLE memo CASCADE CONSTRAINTS;

CREATE TABLE memo(
		memono                        		NUMBER(10)		 NOT NULL		 PRIMARY KEY,
		title                         		VARCHAR2(300)		 NOT NULL,
		content                       		CLOB		 NOT NULL,
		file1                         		VARCHAR2(100)		 NULL ,
		file1saved                    		VARCHAR2(100)		 NULL ,
		thumb1                        		VARCHAR2(100)		 NULL ,
		size1                         		NUMBER(10)		 DEFAULT 0		 NULL ,
		sw                            		CHAR(1)		 DEFAULT 'A'		 NULL ,
		rdate                         		DATE		 NOT NULL
);

COMMENT ON TABLE memo is 'memo';
COMMENT ON COLUMN memo.memono is '메모번호';
COMMENT ON COLUMN memo.title is '제목';
COMMENT ON COLUMN memo.content is '컨텐츠';
COMMENT ON COLUMN memo.file1 is '원본파일명';
COMMENT ON COLUMN memo.file1saved is '저장된파일명';
COMMENT ON COLUMN memo.thumb1 is '미리보기이미지';
COMMENT ON COLUMN memo.size1 is '파일사이즈';
COMMENT ON COLUMN memo.sw is '상태';
COMMENT ON COLUMN memo.rdate is '생성일';

DROP SEQUENCE memo_seq;

CREATE SEQUENCE memo_seq
  START WITH 1                -- 시작 번호
  INCREMENT BY 1            -- 증가값
  MAXVALUE 9999999999  -- 최대값: 9999999999 --> NUMBER(10) 대응
  CACHE 2                        -- 2번은 메모리에서만 계산
  NOCYCLE;                      -- 다시 1부터 생성되는 것을 방지

SELECT memono, title, content, file1, file1saved, thumb1, size1, sw, rdate
FROM memo
WHERE title LIKE '%정보처리%' OR content LIKE '%정보처리%'
ORDER BY memono DESC;
