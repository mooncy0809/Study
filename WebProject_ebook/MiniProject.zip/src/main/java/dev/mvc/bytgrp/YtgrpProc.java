package dev.mvc.bytgrp;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
 
// Autowired 기능에의해 자동 할당될 때 사용되는 이름
@Component("dev.mvc.bytgrp.YtgrpProc")
public class YtgrpProc implements YtgrpProcInter {
  /* DI: 객체가 필요한 곳에 객체를 자동으로 생성하여 할당
      Autowired: DI 사용 선언
     ① Spring이 자동으로 YtgrpDAOInter를 구현(DAO class 생성)
     ② 객체 생성: private YtgrpDAOInter ytgrpDAO = new YtgrpDAO();
     ③ ytgrpDAO에 생성된 객체를 할당 */     
  @Autowired 
  private YtgrpDAOInter ytgrpDAO;

  @Override
  public int create(YtgrpVO ytgrpVO) {
    int cnt = ytgrpDAO.create(ytgrpVO);
    
    return cnt;
  }
  @Override
  public List<YtgrpVO> list_ytgrpno_asc() {
    List<YtgrpVO> list = this.ytgrpDAO.list_ytgrpno_asc();
    return list;
  }
  
  @Override
  public YtgrpVO read(int ytgrpno) {
      YtgrpVO ytgrpVO = this.ytgrpDAO.read(ytgrpno);  
    return ytgrpVO;
  }
  @Override
  public int update(YtgrpVO ytgrpVO) {
    int cnt = 0;
    cnt = this.ytgrpDAO.update(ytgrpVO);
    
    return cnt;
  }
  
  @Override
  public int delete(int ytgrpno) {
    int cnt = this.ytgrpDAO.delete(ytgrpno);
    return cnt;
  }
  @Override
  public int update_visible(YtgrpVO ytgrpVO) {
    int cnt = 0;
    if (ytgrpVO.getVisible().toUpperCase().equals("Y")) {
        ytgrpVO.setVisible("N");
    } else {
        ytgrpVO.setVisible("Y");
    }
    cnt = this.ytgrpDAO.update_visible(ytgrpVO);
    return cnt;
  }
}
 
