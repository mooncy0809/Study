package dev.mvc.bytgrp;

import java.util.List;

import dev.mvc.bytgrp.YtgrpVO;

public interface YtgrpProcInter {
    /**
     * 등록
     * @param ytgrpVO
     * @return 등록된 레코드 갯수
     */
    public int create(YtgrpVO ytgrpVO);
    
    /**
     * 등록 순서별 목록
     * @return
     */
    public List<YtgrpVO> list_ytgrpno_asc();
    
    /**
     * 조회, 수정폼
     * @param categrpno 카테고리 그룹 번호, PK
     * @return
     */
    public YtgrpVO read(int ytgrpno);
    
    /**
     * 수정 처리
     * @param ytgrpVO
     * @return 처리된 레코드 갯수
     */
    public int update(YtgrpVO ytgrpVO);
    
    /**
     * 삭제 처리
     * @param ytgrpno
     * @return 처리된 레코드 갯수
     */
    public int delete(int ytgrpno);
    /**
     * visible 수정
     * @param categrpVO
     * @return
     */
    public int update_visible(YtgrpVO ytgrpVO);
}

