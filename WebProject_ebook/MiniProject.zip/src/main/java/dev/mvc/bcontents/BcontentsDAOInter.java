package dev.mvc.bcontents;

import java.util.HashMap;
import java.util.List;

public interface BcontentsDAOInter {
  /**
   * 등록
   * @param bcontentsVO
   * @return
   */
  public int create(BcontentsVO bcontentsVO);
  /**
   * 조회
   * @param bcontentsno
   * @return
   */
  public BcontentsVO read(int bcontentsno);
  /**
   * 상품 정보 수정 처리
   * @param contentsVO
   * @return
   */
  public int product_update(BcontentsVO bcontentsVO);
  
  /**
   * 특정 카테고리의 등록된 글목록
   * @return
   */
  public List<BcontentsVO> list_by_cateno(int bcateno);
  
  /**
   * 카테고리별 검색 목록
   * @param hashMap
   * @return
   */
  public List<BcontentsVO> list_by_cateno_search(HashMap<String, Object> hashMap);

  /**
   * 카테고리별 검색 레코드 갯수
   * @param hashMap
   * @return
   */
  public int search_count(HashMap<String, Object> hashMap);
}