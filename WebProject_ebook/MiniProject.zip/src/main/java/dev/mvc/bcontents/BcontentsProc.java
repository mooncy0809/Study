package dev.mvc.bcontents;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import dev.mvc.tool.Tool;

@Component("dev.mvc.bcontents.BcontentsProc")
  public class BcontentsProc implements BcontentsProcInter {
    @Autowired
    private BcontentsDAOInter bcontentsDAO;

    @Override
    public int create(BcontentsVO bcontentsVO) {
      int cnt=this.bcontentsDAO.create(bcontentsVO);
      return cnt;
    }
    /**
     * 조회
     */
    @Override
    public BcontentsVO read(int bcontentsno) {
      BcontentsVO bcontentsVO = this.bcontentsDAO.read(bcontentsno);
      return bcontentsVO;
    }
    @Override
    public int product_update(BcontentsVO bcontentsVO) {
      int cnt = this.bcontentsDAO.product_update(bcontentsVO);
      return cnt;
    }
    
    @Override
    public List<BcontentsVO> list_by_cateno(int bcateno) {
      List<BcontentsVO> list = this.bcontentsDAO.list_by_cateno(bcateno);
  
      for (BcontentsVO bcontentsVO : list) {
          String content = bcontentsVO.getContent();

          if (content.length() > 160) { // 160 초과이면 160자만 선택
              content = content.substring(0, 160) + "...";
              bcontentsVO.setContent(content);
          }

          String title = bcontentsVO.getTitle();

          title = Tool.convertChar(title); // 특수 문자 처리
          content = Tool.convertChar(content);

          bcontentsVO.setTitle(title);
          bcontentsVO.setContent(content);
      }
      
      return list;
    }
}