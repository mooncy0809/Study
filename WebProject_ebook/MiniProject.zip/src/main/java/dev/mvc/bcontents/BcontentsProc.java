package dev.mvc.bcontents;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import dev.mvc.tool.Tool;

@Component("dev.mvc.bcontents.BcontentsProc")
  public class BcontentsProc implements BcontentsProcInter {
    @Autowired
    private BcontentsDAOInter bcontentsDAO;

    @Override
    public int create(BcontentsVO bcontentsVO) {
      int cnt=this.bcontentsDAO.create(bcontentsVO);
      return cnt;
    }
    /**
     * 조회
     */
    @Override
    public BcontentsVO read(int bcontentsno) {
        BcontentsVO bcontentsVO = this.bcontentsDAO.read(bcontentsno);
      
      String title = bcontentsVO.getTitle();
      String content = bcontentsVO.getContent();
      
      title = Tool.convertChar(title);  // 특수 문자 처리
      content = Tool.convertChar(content); 
      
      bcontentsVO.setTitle(title);
      bcontentsVO.setContent(content);  
      
      long size1 = bcontentsVO.getSize1();
      bcontentsVO.setSize1_label(Tool.unit(size1));
      
      return bcontentsVO;
    }

    @Override
    public int product_update(BcontentsVO bcontentsVO) {
      int cnt = this.bcontentsDAO.product_update(bcontentsVO);
      return cnt;
    }
    
    @Override
    public List<BcontentsVO> list_by_cateno(int bcateno) {
      List<BcontentsVO> list = this.bcontentsDAO.list_by_cateno(bcateno);
  
      for (BcontentsVO bcontentsVO : list) {
          String content = bcontentsVO.getContent();

          if (content.length() > 160) { // 160 초과이면 160자만 선택
              content = content.substring(0, 160) + "...";
              bcontentsVO.setContent(content);
          }

          String title = bcontentsVO.getTitle();

          title = Tool.convertChar(title); // 특수 문자 처리
          content = Tool.convertChar(content);

          bcontentsVO.setTitle(title);
          bcontentsVO.setContent(content);
      }
      
      return list;
    }
    
    @Override
    public List<BcontentsVO> list_by_cateno_search(HashMap<String, Object> hashMap) {
      List<BcontentsVO> list = bcontentsDAO.list_by_cateno_search(hashMap);
      
      for (BcontentsVO bcontentsVO : list) { // 내용이 160자 이상이면 160자만 선택
        String content = bcontentsVO.getContent();
        if (content.length() > 160) {
          content = content.substring(0, 160) + "...";
          bcontentsVO.setContent(content);
        }
      }
      
      return list;
    }

    @Override
    public int search_count(HashMap<String, Object> hashMap) {
      int count = bcontentsDAO.search_count(hashMap);
      return count;
    }
}