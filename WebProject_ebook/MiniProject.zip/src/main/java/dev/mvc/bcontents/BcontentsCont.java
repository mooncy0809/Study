package dev.mvc.bcontents;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import dev.mvc.bcate.BcateProcInter;
import dev.mvc.bcate.BcateVO;
import dev.mvc.bcategrp.BcategrpProcInter;
import dev.mvc.bcategrp.BcategrpVO;
//import dev.mvc.member.MemberProcInter;
import dev.mvc.tool.Tool;
import dev.mvc.tool.Upload;

@Controller
public class BcontentsCont {
  @Autowired
  @Qualifier("dev.mvc.bcategrp.BcategrpProc")
  private BcategrpProcInter bcategrpProc;
  
  @Autowired
  @Qualifier("dev.mvc.bcate.BcateProc")
  private BcateProcInter bcateProc;
  
  @Autowired
  @Qualifier("dev.mvc.bcontents.BcontentsProc")
  private BcontentsProcInter bcontentsProc;
  
  public BcontentsCont() {
    System.out.println("-> BcontentsCont created.");
  }

  /**
   * 새로고침 방지
   * @return
   */
  @RequestMapping(value="/bcontents/msg.do", method=RequestMethod.GET)
  public ModelAndView msg(String url){
    ModelAndView mav = new ModelAndView();

    mav.setViewName(url); // forward
    
    return mav; // forward
  }
  
  /**
   * 등록폼 
   * 사전 준비된 레코드: 관리자 1번, bcateno 1번, bcategrpno 1번을 사용하는 경우 테스트 URL
   * http://localhost:9091/bcontents/create.do?bcateno=1&adminno=1 FK 값 명시
   * 
   * @return
   */
  @RequestMapping(value = "/bcontents/create.do", method = RequestMethod.GET)
  public ModelAndView create(int bcateno, int adminno) {
    ModelAndView mav = new ModelAndView();
    
    BcateVO bcateVO = this.bcateProc.read(bcateno);
    BcategrpVO bcategrpVO = this.bcategrpProc.read(bcateVO.getBcategrpno());
    
    mav.addObject("bcateVO", bcateVO);
    mav.addObject("bcategrpVO", bcategrpVO);
    
    mav.setViewName("/bcontents/create"); 

    return mav; // forward
  }
  /**
   * 등록 처리 http://localhost:9091/bcontents/create.do
   * 
   * @return
   */
  @RequestMapping(value = "/bcontents/create.do", method = RequestMethod.POST)
  public ModelAndView create(HttpServletRequest request, BcontentsVO bcontentsVO) {
    ModelAndView mav = new ModelAndView();
    
    // ------------------------------------------------------------------------------
    // 파일 전송 코드 시작
    // ------------------------------------------------------------------------------
    String file1 = "";          // 원본 파일명 image
    String file1saved = "";  // 저장된 파일명, image
    String thumb1 = "";     // preview image

    // 기준 경로 확인
    String user_dir = System.getProperty("user.dir"); // 시스템 제공
    // System.out.println("-> User dir: " + user_dir);
    //  --> User dir: C:\kd1\ws_java\resort_v1sbm3c
    
    // 파일 접근임으로 절대 경로 지정, static 폴더 지정
    // 완성된 경로 C:/kd1/ws_java/resort_v1sbm3c/src/main/resources/static/bcontents/storage
    String upDir =  user_dir + "/src/main/resources/static/contents/storage/"; // 절대 경로
    // System.out.println("-> upDir: " + upDir);
    
    // 전송 파일이 없어도 file1MF 객체가 생성됨.
    // <input type='file' class="form-control" name='file1MF' id='file1MF' 
    //           value='' placeholder="파일 선택">
    MultipartFile mf = bcontentsVO.getFile1MF();
    
    file1 = Tool.getFname(mf.getOriginalFilename()); // 원본 순수 파일명 산출
    // System.out.println("-> file1: " + file1);
    
    long size1 = mf.getSize();  // 파일 크기
    
    if (size1 > 0) { // 파일 크기 체크
      // 파일 저장 후 업로드된 파일명이 리턴됨, spring.jsp, spring_1.jpg...
      file1saved = Upload.saveFileSpring(mf, upDir); 
      
      if (Tool.isImage(file1saved)) { // 이미지인지 검사
        // thumb 이미지 생성후 파일명 리턴됨, width: 200, height: 150
        thumb1 = Tool.preview(upDir, file1saved, 200, 150); 
      }
      
    }    
    
    bcontentsVO.setFile1(file1);
    bcontentsVO.setFile1saved(file1saved);
    bcontentsVO.setThumb1(thumb1);
    bcontentsVO.setSize1(size1);
    // ------------------------------------------------------------------------------
    // 파일 전송 코드 종료
    // ------------------------------------------------------------------------------
    
    // Call By Reference: 메모리 공유, Hashcode 전달
    int cnt = this.bcontentsProc.create(bcontentsVO); 
    
    // ------------------------------------------------------------------------------
    // PK의 return
    // ------------------------------------------------------------------------------
     System.out.println("--> bcontentsno: " + bcontentsVO.getBcontentsno());
     mav.addObject("bcontentsno", bcontentsVO.getBcontentsno()); // redirect parameter 적용
    // ------------------------------------------------------------------------------
    
    if (cnt == 1) {
        mav.addObject("code", "create_success");
        // bcateProc.increaseCnt(bcontentsVO.getCateno()); // 글수 증가
    } else {
        mav.addObject("code", "create_fail");
    }
    mav.addObject("cnt", cnt); 
    
    mav.addObject("bcateno", bcontentsVO.getBcateno()); // redirect parameter 적용
    mav.addObject("url", "/bcontents/msg"); // msg.jsp, redirect parameter 적용

    mav.setViewName("redirect:/bcontents/msg.do"); 
    
    return mav; // forward
  }
  /**
   * 상품 정보 수정 폼
   * 사전 준비된 레코드: 관리자 1번, bcateno 1번, bcategrpno 1번을 사용하는 경우 테스트 URL
   * http://localhost:9091/bcontents/create.do?bcateno=1
   * 
   * @return
   */
  @RequestMapping(value = "/bcontents/product_update.do", method = RequestMethod.GET)
  public ModelAndView product_update(int bcateno, int bcontentsno) {
    ModelAndView mav = new ModelAndView();
    
    BcateVO bcateVO = this.bcateProc.read(bcateno);
    BcategrpVO bcategrpVO = this.bcategrpProc.read(bcateVO.getBcategrpno());
    BcontentsVO bcontentsVO = this.bcontentsProc.read(bcontentsno);
    
    mav.addObject("bcateVO", bcateVO);
    mav.addObject("bcategrpVO", bcategrpVO);
    mav.addObject("bcontentsVO", bcontentsVO);
    
    mav.setViewName("/bcontents/product_update"); // /views/bcontents/product_update.jsp
    // String content = "장소:\n인원:\n준비물:\n비용:\n기타:\n";
    // mav.addObject("content", content);

    return mav; // forward
  }
  
    /**
  * 상품 정보 수정 처리 http://localhost:9091/bcontents/product_update.do
  * 
  * @return
  */
 @RequestMapping(value = "/bcontents/product_update.do", method = RequestMethod.POST)
 public ModelAndView product_update(BcontentsVO bcontentsVO) {
   ModelAndView mav = new ModelAndView();
   
   // Call By Reference: 메모리 공유, Hashcode 전달
   int cnt = this.bcontentsProc.product_update(bcontentsVO);
   
   mav.addObject("cnt", cnt); // request.setAttribute("cnt", cnt)
   mav.addObject("bcateno", bcontentsVO.getBcateno()); // redirect parameter 적용

   // 연속 입력 지원용 변수, Call By Reference에 기반하여 bcontentsno를 전달 받음
   mav.addObject("bcontentsno", bcontentsVO.getBcontentsno());
   
   mav.addObject("url", "/bcontents/msg");  // msg.jsp

   if (cnt == 1) {
       mav.addObject("code", "product_success"); 
   } else {
       mav.addObject("code", "product_fail"); 
   }
   
   mav.setViewName("redirect:/bcontents/msg.do"); 
   
   return mav; // forward
 }
 
 /**
  * 카테고리별 목록 http://localhost:9091/bcontents/list_by_cateno.do?cateno=1
  * 
  * @return
  */
  @RequestMapping(value = "/bcontents/list_by_cateno.do", method = RequestMethod.GET)
   public ModelAndView list_by_cateno(int bcateno) { 
     ModelAndView mav = new  ModelAndView(); 
     mav.setViewName("/bcontents/list_by_cateno");
     
     // 테이블 이미지 기반, /webapp/bcontents/list_by_cateno.jsp
     mav.setViewName("/bcontents/list_by_cateno");
     
     BcateVO bcateVO = this.bcateProc.read(bcateno); mav.addObject("bcateVO", bcateVO);
     
     BcategrpVO bcategrpVO = this.bcategrpProc.read(bcateVO.getBcategrpno());
     mav.addObject("bcategrpVO", bcategrpVO);
     
     List<BcontentsVO> list = this.bcontentsProc.list_by_cateno(bcateno);
     mav.addObject("list", list);
     
     return mav; // forward 
   }
  
  /**
   * 조회
   * @return
   */
  @RequestMapping(value="/bcontents/read.do", method=RequestMethod.GET )
  public ModelAndView read(int bcontentsno) {
    ModelAndView mav = new ModelAndView();

    BcontentsVO bcontentsVO = this.bcontentsProc.read(bcontentsno);
    mav.addObject("bcontentsVO", bcontentsVO); // request.setAttribute("contentsVO", contentsVO);

    BcateVO bcateVO = this.bcateProc.read(bcontentsVO.getBcateno());
    mav.addObject("bcateVO", bcateVO); 

    BcategrpVO bcategrpVO = this.bcategrpProc.read(bcateVO.getBcategrpno());
    mav.addObject("bcategrpVO", bcategrpVO); 
    
    mav.setViewName("/bcontents/read"); // /WEB-INF/views/contents/read.jsp
        
    return mav;
  }
  
  /**
   * 목록 + 검색 지원
   * http://localhost:9090/bcontents/list_by_cateno_search.do?bcateno=1&word=스위스
   * @param bcateno
   * @param word
   * @return
   */
    @RequestMapping(value = "/bcontents/list_by_cateno_search.do", method = RequestMethod.GET)
    public ModelAndView list_by_cateno_search(@RequestParam(value="bcateno", defaultValue="1") int bcateno,
                                                                    @RequestParam(value="word", defaultValue="") String word ) {
    
    ModelAndView mav = new ModelAndView(); 
         
    // 숫자와 문자열 타입을 저장해야함으로 Obejct 사용 
    HashMap<String, Object> map = new HashMap<String, Object>(); 
    map.put("bcateno", bcateno); // #{cateno}
    map.put("word", word); // #{word}
    
    // 검색 목록 
    List<BcontentsVO> list = bcontentsProc.list_by_cateno_search(map);
    mav.addObject("list", list);
    
    // 검색된 레코드 갯수 
    int search_count = bcontentsProc.search_count(map);
    mav.addObject("search_count", search_count);
    
    BcateVO bcateVO = bcateProc.read(bcateno); 
    mav.addObject("bcateVO", bcateVO);
    
    BcategrpVO bcategrpVO = this.bcategrpProc.read(bcateVO.getBcategrpno());
    mav.addObject("bcategrpVO", bcategrpVO);
    
    mav.setViewName("/bcontents/list_by_cateno_search");   // /contents/list_by_cateno_search.jsp
    
    return mav; 
  }
}