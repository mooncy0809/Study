package dev.mvc.bcontents;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import dev.mvc.bcate.BcateProcInter;
import dev.mvc.bcate.BcateVO;
import dev.mvc.bcategrp.BcategrpProcInter;
import dev.mvc.bcategrp.BcategrpVO;

//import dev.mvc.member.MemberProcInter;
import dev.mvc.tool.Tool;
import dev.mvc.tool.Upload;

@Controller
public class BcontentsCont {
  @Autowired
  @Qualifier("dev.mvc.bcategrp.BcategrpProc")
  private BcategrpProcInter bcategrpProc;
  
  @Autowired
  @Qualifier("dev.mvc.bcate.BcateProc")
  private BcateProcInter bcateProc;
  
  @Autowired
  @Qualifier("dev.mvc.bcontents.BcontentsProc")
  private BcontentsProcInter bcontentsProc;
  
  public BcontentsCont() {
    System.out.println("-> BcontentsCont created.");
  }

  /**
   * 새로고침 방지
   * @return
   */
  @RequestMapping(value="/bcontents/msg.do", method=RequestMethod.GET)
  public ModelAndView msg(String url){
    ModelAndView mav = new ModelAndView();

    mav.setViewName(url); // forward
    
    return mav; // forward
  }
  
  /**
   * 등록폼 
   * 사전 준비된 레코드: 관리자 1번, bcateno 1번, bcategrpno 1번을 사용하는 경우 테스트 URL
   * http://localhost:9091/bcontents/create.do?bcateno=1&adminno=1 FK 값 명시
   * 
   * @return
   */
  @RequestMapping(value = "/bcontents/create.do", method = RequestMethod.GET)
  public ModelAndView create(int bcateno, int adminno) {
    ModelAndView mav = new ModelAndView();
    
    BcateVO bcateVO = this.bcateProc.read(bcateno);
    BcategrpVO bcategrpVO = this.bcategrpProc.read(bcateVO.getBcategrpno());
    
    mav.addObject("bcateVO", bcateVO);
    mav.addObject("bcategrpVO", bcategrpVO);
    
    mav.setViewName("/bcontents/create"); 

    return mav; // forward
  }
  /**
   * 등록 처리 http://localhost:9091/bcontents/create.do
   * 
   * @return
   */
  @RequestMapping(value = "/bcontents/create.do", method = RequestMethod.POST)
  public ModelAndView create(HttpServletRequest request, BcontentsVO bcontentsVO) {
    ModelAndView mav = new ModelAndView();
    
    // ------------------------------------------------------------------------------
    // 파일 전송 코드 시작
    // ------------------------------------------------------------------------------
    String file1 = "";          // 원본 파일명 image
    String file1saved = "";  // 저장된 파일명, image
    String thumb1 = "";     // preview image

    // 기준 경로 확인
    String user_dir = System.getProperty("user.dir"); // 시스템 제공
    // System.out.println("-> User dir: " + user_dir);
    //  --> User dir: C:\kd1\ws_java\resort_v1sbm3c
    
    // 파일 접근임으로 절대 경로 지정, static 폴더 지정
    // 완성된 경로 C:/kd1/ws_java/resort_v1sbm3c/src/main/resources/static/bcontents/storage
    String upDir =  user_dir + "/src/main/resources/static/contents/storage/"; // 절대 경로
    // System.out.println("-> upDir: " + upDir);
    
    // 전송 파일이 없어도 file1MF 객체가 생성됨.
    // <input type='file' class="form-control" name='file1MF' id='file1MF' 
    //           value='' placeholder="파일 선택">
    MultipartFile mf = bcontentsVO.getFile1MF();
    
    file1 = Tool.getFname(mf.getOriginalFilename()); // 원본 순수 파일명 산출
    // System.out.println("-> file1: " + file1);
    
    long size1 = mf.getSize();  // 파일 크기
    
    if (size1 > 0) { // 파일 크기 체크
      // 파일 저장 후 업로드된 파일명이 리턴됨, spring.jsp, spring_1.jpg...
      file1saved = Upload.saveFileSpring(mf, upDir); 
      
      if (Tool.isImage(file1saved)) { // 이미지인지 검사
        // thumb 이미지 생성후 파일명 리턴됨, width: 200, height: 150
        thumb1 = Tool.preview(upDir, file1saved, 200, 150); 
      }
      
    }    
    
    bcontentsVO.setFile1(file1);
    bcontentsVO.setFile1saved(file1saved);
    bcontentsVO.setThumb1(thumb1);
    bcontentsVO.setSize1(size1);
    // ------------------------------------------------------------------------------
    // 파일 전송 코드 종료
    // ------------------------------------------------------------------------------
    
    // Call By Reference: 메모리 공유, Hashcode 전달
    int cnt = this.bcontentsProc.create(bcontentsVO); 
    
    // ------------------------------------------------------------------------------
    // PK의 return
    // ------------------------------------------------------------------------------
     System.out.println("--> bcontentsno: " + bcontentsVO.getBcontentsno());
     mav.addObject("bcontentsno", bcontentsVO.getBcontentsno()); // redirect parameter 적용
    // ------------------------------------------------------------------------------
    
    if (cnt == 1) {
        mav.addObject("code", "create_success");
        // bcateProc.increaseCnt(bcontentsVO.getCateno()); // 글수 증가
    } else {
        mav.addObject("code", "create_fail");
    }
    mav.addObject("cnt", cnt); 
    
    mav.addObject("bcateno", bcontentsVO.getBcateno()); // redirect parameter 적용
    mav.addObject("url", "/bcontents/msg"); // msg.jsp, redirect parameter 적용

    mav.setViewName("redirect:/bcontents/msg.do"); 
    
    return mav; // forward
  }
  /**
   * 상품 정보 수정 폼
   * 사전 준비된 레코드: 관리자 1번, bcateno 1번, bcategrpno 1번을 사용하는 경우 테스트 URL
   * http://localhost:9091/bcontents/create.do?bcateno=1
   * 
   * @return
   */
  @RequestMapping(value = "/bcontents/product_update.do", method = RequestMethod.GET)
  public ModelAndView product_update(int bcateno, int bcontentsno) {
    ModelAndView mav = new ModelAndView();
    
    BcateVO bcateVO = this.bcateProc.read(bcateno);
    BcategrpVO bcategrpVO = this.bcategrpProc.read(bcateVO.getBcategrpno());
    BcontentsVO bcontentsVO = this.bcontentsProc.read(bcontentsno);
    
    mav.addObject("bcateVO", bcateVO);
    mav.addObject("bcategrpVO", bcategrpVO);
    mav.addObject("bcontentsVO", bcontentsVO);
    
    mav.setViewName("/bcontents/product_update"); // /views/bcontents/product_update.jsp
    // String content = "장소:\n인원:\n준비물:\n비용:\n기타:\n";
    // mav.addObject("content", content);

    return mav; // forward
  }
  
    /**
  * 상품 정보 수정 처리 http://localhost:9091/bcontents/product_update.do
  * 
  * @return
  */
 @RequestMapping(value = "/bcontents/product_update.do", method = RequestMethod.POST)
 public ModelAndView product_update(BcontentsVO bcontentsVO) {
   ModelAndView mav = new ModelAndView();
   
   // Call By Reference: 메모리 공유, Hashcode 전달
   int cnt = this.bcontentsProc.product_update(bcontentsVO);
   
   mav.addObject("cnt", cnt); // request.setAttribute("cnt", cnt)
   mav.addObject("bcateno", bcontentsVO.getBcateno()); // redirect parameter 적용

   // 연속 입력 지원용 변수, Call By Reference에 기반하여 bcontentsno를 전달 받음
   mav.addObject("bcontentsno", bcontentsVO.getBcontentsno());
   
   mav.addObject("url", "/bcontents/msg");  // msg.jsp

   if (cnt == 1) {
       mav.addObject("code", "product_success"); 
   } else {
       mav.addObject("code", "product_fail"); 
   }
   
   mav.setViewName("redirect:/bcontents/msg.do"); 
   
   return mav; // forward
 }
 
 /**
  * 카테고리별 목록 http://localhost:9091/bcontents/list_by_cateno.do?cateno=1
  * 
  * @return
  */
  @RequestMapping(value = "/bcontents/list_by_cateno.do", method = RequestMethod.GET)
   public ModelAndView list_by_cateno(int bcateno) { 
     ModelAndView mav = new  ModelAndView(); 
     mav.setViewName("/bcontents/list_by_cateno");
     
     // 테이블 이미지 기반, /webapp/bcontents/list_by_cateno.jsp
     mav.setViewName("/bcontents/list_by_cateno");
     
     BcateVO bcateVO = this.bcateProc.read(bcateno); mav.addObject("bcateVO", bcateVO);
     
     BcategrpVO bcategrpVO = this.bcategrpProc.read(bcateVO.getBcategrpno());
     mav.addObject("bcategrpVO", bcategrpVO);
     
     List<BcontentsVO> list = this.bcontentsProc.list_by_cateno(bcateno);
     mav.addObject("list", list);
     
     return mav; // forward 
   }
  
  /**
   * 조회
   * @return
   */
  @RequestMapping(value="/bcontents/read.do", method=RequestMethod.GET )
  public ModelAndView read(int bcontentsno) {
    ModelAndView mav = new ModelAndView();

    BcontentsVO bcontentsVO = this.bcontentsProc.read(bcontentsno);
    mav.addObject("bcontentsVO", bcontentsVO); // request.setAttribute("contentsVO", contentsVO);

    BcateVO bcateVO = this.bcateProc.read(bcontentsVO.getBcateno());
    mav.addObject("bcateVO", bcateVO); 

    BcategrpVO bcategrpVO = this.bcategrpProc.read(bcateVO.getBcategrpno());
    mav.addObject("bcategrpVO", bcategrpVO); 
    
    mav.setViewName("/bcontents/read"); // /WEB-INF/views/contents/read.jsp
        
    return mav;
  }
  
  /**
   * 목록 + 검색 지원
   * http://localhost:9090/bcontents/list_by_cateno_search.do?bcateno=1&word=스위스
   * @param bcateno
   * @param word
   * @return
   */
    @RequestMapping(value = "/bcontents/list_by_cateno_search.do", method = RequestMethod.GET)
    public ModelAndView list_by_cateno_search(@RequestParam(value="bcateno", defaultValue="1") int bcateno,
                                                                    @RequestParam(value="word", defaultValue="") String word ) {
    
    ModelAndView mav = new ModelAndView(); 
         
    // 숫자와 문자열 타입을 저장해야함으로 Obejct 사용 
    HashMap<String, Object> map = new HashMap<String, Object>(); 
    map.put("bcateno", bcateno); // #{cateno}
    map.put("word", word); // #{word}
    
    // 검색 목록 
    List<BcontentsVO> list = bcontentsProc.list_by_cateno_search(map);
    mav.addObject("list", list);
    
    // 검색된 레코드 갯수 
    int search_count = bcontentsProc.search_count(map);
    mav.addObject("search_count", search_count);
    
    BcateVO bcateVO = bcateProc.read(bcateno); 
    mav.addObject("bcateVO", bcateVO);
    
    BcategrpVO bcategrpVO = this.bcategrpProc.read(bcateVO.getBcategrpno());
    mav.addObject("bcategrpVO", bcategrpVO);
    
    mav.setViewName("/bcontents/list_by_cateno_search");   // /contents/list_by_cateno_search.jsp
    
    return mav; 
  }
    
    /**
     * 목록 + 검색 + 페이징 지원
     * http://localhost:9090/bcontents/list_by_cateno_search_paging.do?bcateno=1&word=스위스&now_page=1
     * 
     * @param bcateno
     * @param word
     * @param now_page
     * @return
     */
    @RequestMapping(value = "/bcontents/list_by_cateno_search_paging.do", method = RequestMethod.GET)
    public ModelAndView list_by_cateno_search_paging(@RequestParam(value = "bcateno", defaultValue = "1") int bcateno,
                                                                           @RequestParam(value = "word", defaultValue = "") String word,
                                                                           @RequestParam(value = "now_page", defaultValue = "1") int now_page) {
      System.out.println("--> now_page: " + now_page);

      ModelAndView mav = new ModelAndView();

      // 숫자와 문자열 타입을 저장해야함으로 Obejct 사용
      HashMap<String, Object> map = new HashMap<String, Object>();
      map.put("bcateno", bcateno); // #{bcateno}
      map.put("word", word); // #{word}
      map.put("now_page", now_page); // 페이지에 출력할 레코드의 범위를 산출하기위해 사용

      // 검색 목록
      List<BcontentsVO> list = bcontentsProc.list_by_cateno_search_paging(map);
      mav.addObject("list", list);

      // 검색된 레코드 갯수
      int search_count = bcontentsProc.search_count(map);
      mav.addObject("search_count", search_count);

      BcateVO bcateVO = bcateProc.read(bcateno);
      mav.addObject("bcateVO", bcateVO);

      BcategrpVO bcategrpVO = bcategrpProc.read(bcateVO.getBcategrpno());
      mav.addObject("bcategrpVO", bcategrpVO);

      /*
       * SPAN태그를 이용한 박스 모델의 지원, 1 페이지부터 시작 현재 페이지: 11 / 22 [이전] 11 12 13 14 15 16 17
       * 18 19 20 [다음]
       * @param bcateno 카테고리번호
       * @param search_count 검색(전체) 레코드수
       * @param now_page 현재 페이지
       * @param word 검색어
       * @return 페이징 생성 문자열
       */
      String paging = bcontentsProc.pagingBox(bcateno, search_count, now_page, word);
      mav.addObject("paging", paging);

      mav.addObject("now_page", now_page);

      // /bcontents/list_by_cateno_table_img1_search_paging.jsp
      mav.setViewName("/bcontents/list_by_cateno_search_paging");

      return mav;
    }
    
    /**
     * Grid 형태의 화면 구성 http://localhost:9091/bcontents/list_by_cateno_grid.do
     * 
     * @return
     */
    @RequestMapping(value = "/bcontents/list_by_cateno_grid.do", method = RequestMethod.GET)
    public ModelAndView list_by_cateno_grid(int bcateno) {
      ModelAndView mav = new ModelAndView();
      
      BcateVO bcateVO = this.bcateProc.read(bcateno);
      mav.addObject("bcateVO", bcateVO);
      
      BcategrpVO bcategrpVO = this.bcategrpProc.read(bcateVO.getBcategrpno());
      mav.addObject("bcategrpVO", bcategrpVO);
      
      List<BcontentsVO> list = this.bcontentsProc.list_by_cateno(bcateno);
      mav.addObject("list", list);

      // 테이블 이미지 기반, /webapp/bcontents/list_by_cateno_grid.jsp
      mav.setViewName("/bcontents/list_by_cateno_grid");

      return mav; // forward
    }
    /**
     * 수정 폼
     * http://localhost:9091/bcontents/update_text.do?bcontentsno=1
     * 
     * @return
     */
    @RequestMapping(value = "/bcontents/update_text.do", method = RequestMethod.GET)
    public ModelAndView update_text(int bcontentsno) {
      ModelAndView mav = new ModelAndView();
      
      BcontentsVO bcontentsVO = this.bcontentsProc.read_update_text(bcontentsno);
      BcateVO bcateVO = this.bcateProc.read(bcontentsVO.getBcateno());
      BcategrpVO bcategrpVO = this.bcategrpProc.read(bcateVO.getBcategrpno());
      
      mav.addObject("bcontentsVO", bcontentsVO);
      mav.addObject("bcateVO", bcateVO);
      mav.addObject("bcategrpVO", bcategrpVO);
      
      mav.setViewName("/bcontents/update_text"); // /WEB-INF/views/bcontents/update_text.jsp
      // String content = "장소:\n인원:\n준비물:\n비용:\n기타:\n";
      // mav.addObject("content", content);

      return mav; // forward
    }

    /**
     * 수정 처리
     * http://localhost:9091/bcontents/update_text.do?bcontentsno=1
     * 
     * @return
     */
    @RequestMapping(value = "/bcontents/update_text.do", method = RequestMethod.POST)
    public ModelAndView update_text(BcontentsVO bcontentsVO,
                                                    @RequestParam(value = "word", defaultValue = "") String word_search,
                                                    @RequestParam(value = "now_page", defaultValue = "1") int now_page) {
      ModelAndView mav = new ModelAndView();
      
      HashMap<String, Object> map = new HashMap<String, Object>();
      map.put("bcontentsno", bcontentsVO.getBcontentsno());
      map.put("passwd", bcontentsVO.getPasswd());
      
      int cnt = 0;
      int passwd_cnt = this.bcontentsProc.passwd_check(map);
      if (passwd_cnt == 1) {
          cnt = this.bcontentsProc.update_text(bcontentsVO); // 수정 처리
          
          mav.addObject("word", word_search);
          mav.addObject("now_page", now_page);
          mav.addObject("bcontentsno", bcontentsVO.getBcontentsno());
          mav.setViewName("redirect:/bcontents/read.do");             
      } else {
          mav.addObject("cnt", cnt);
          mav.addObject("code", "passwd_fail");
          mav.addObject("url", "/bcontents/msg"); 
          mav.addObject("now_page", now_page);
          mav.setViewName("redirect:/bcontents/msg.do"); 
      }

      return mav; // forward
    }
    /**
     * 파일 수정 폼
     * http://localhost:9091/bcontents/update_file.do?bcontentsno=1
     * 
     * @return
     */
    @RequestMapping(value = "/bcontents/update_file.do", method = RequestMethod.GET)
    public ModelAndView update_file(int bcontentsno) {
      ModelAndView mav = new ModelAndView();
      
      BcontentsVO bcontentsVO = this.bcontentsProc.read(bcontentsno);
      BcateVO bcateVO = this.bcateProc.read(bcontentsVO.getBcateno());
      BcategrpVO bcategrpVO = this.bcategrpProc.read(bcateVO.getBcategrpno());
      
      mav.addObject("bcontentsVO", bcontentsVO);
      mav.addObject("bcateVO", bcateVO);
      mav.addObject("bcategrpVO", bcategrpVO);
      
      mav.setViewName("/bcontents/update_file"); // /WEB-INF/views/bcontents/update_file.jsp

      return mav; // forward
    }

    /**
     * 파일 수정 처리 http://localhost:9091/bcontents/update_file.do
     * 
     * @return
     */
    @RequestMapping(value = "/bcontents/update_file.do", method = RequestMethod.POST)
    public ModelAndView update_file(HttpServletRequest request, BcontentsVO bcontentsVO, String word, int now_page) {
      ModelAndView mav = new ModelAndView();
      
      // 삭제할 파일 정보를 읽어옴, 기존에 등록된 레코드 저장용
      BcontentsVO bcontentsVO_old = bcontentsProc.read(bcontentsVO.getBcontentsno());
      
      HashMap<String, Object> map = new HashMap<String, Object>();
      map.put("bcontentsno", bcontentsVO.getBcontentsno());
      map.put("passwd", bcontentsVO.getPasswd());
      
      int cnt = 0;
      int passwd_cnt = this.bcontentsProc.passwd_check(map);
      if (passwd_cnt == 1) { // 패스워드 일치 -> 등록된 파일 삭제 -> 신규 파일 등록
          // -------------------------------------------------------------------
          // 파일 삭제 코드 시작
          // -------------------------------------------------------------------
//          System.out.println("bcontentsno: " + vo.getContentsno());
//          System.out.println("file1: " + vo.getFile1());
          
          String file1saved = bcontentsVO_old.getFile1saved();
          String thumb1 = bcontentsVO_old.getThumb1();
          long size1 = 0;
          boolean sw = false;
          
          // 완성된 경로 F:/ai8/ws_frame/resort_v1sbm3a/src/main/resources/static/bcontents/storage/
          String upDir =  System.getProperty("user.dir") + "/src/main/resources/static/contents/storage/"; // 절대 경로

          sw = Tool.deleteFile(upDir, file1saved);  // Folder에서 1건의 파일 삭제
          sw = Tool.deleteFile(upDir, thumb1);     // Folder에서 1건의 파일 삭제
          // System.out.println("sw: " + sw);
          // -------------------------------------------------------------------
          // 파일 삭제 종료 시작
          // -------------------------------------------------------------------
          
          // -------------------------------------------------------------------
          // 파일 전송 코드 시작
          // -------------------------------------------------------------------
          String file1 = "";          // 원본 파일명 image

          // 완성된 경로 F:/ai8/ws_frame/resort_v1sbm3a/src/main/resources/static/contents/storage/
          // String upDir =  System.getProperty("user.dir") + "/src/main/resources/static/contents/storage/"; // 절대 경로
          
          // 전송 파일이 없어도 fnamesMF 객체가 생성됨.
          // <input type='file' class="form-control" name='file1MF' id='file1MF' 
          //           value='' placeholder="파일 선택">
          MultipartFile mf = bcontentsVO.getFile1MF();
          
          file1 = mf.getOriginalFilename(); // 원본 파일명
          size1 = mf.getSize();  // 파일 크기
          
          if (size1 > 0) { // 파일 크기 체크
            // 파일 저장 후 업로드된 파일명이 리턴됨, spring.jsp, spring_1.jpg...
            file1saved = Upload.saveFileSpring(mf, upDir); 
            
            if (Tool.isImage(file1saved)) { // 이미지인지 검사
              // thumb 이미지 생성후 파일명 리턴됨, width: 250, height: 200
              thumb1 = Tool.preview(upDir, file1saved, 250, 200); 
            }
            
          } else { // 파일이 삭제만 되고 새로 올리지 않는 경우
              file1="";
              file1saved="";
              thumb1="";
              size1=0;
          }
          
          bcontentsVO.setFile1(file1);
          bcontentsVO.setFile1saved(file1saved);
          bcontentsVO.setThumb1(thumb1);
          bcontentsVO.setSize1(size1);
          // -------------------------------------------------------------------
          // 파일 전송 코드 종료
          // -------------------------------------------------------------------
          
          // Call By Reference: 메모리 공유, Hashcode 전달
          cnt = this.bcontentsProc.update_file(bcontentsVO);
          System.out.println("-> cnt: " + cnt);
          
          mav.addObject("bcontentsno", bcontentsVO.getBcontentsno());
          mav.addObject("word", word);
          mav.addObject("now_page", now_page);
          mav.setViewName("redirect:/bcontents/read.do"); 
          
      } else { // 패스워드 오류
          mav.addObject("cnt", cnt);
          mav.addObject("code", "passwd_fail");
          mav.addObject("url", "/bcontents/msg"); 
          mav.setViewName("redirect:/bcontents/msg.do");
      }

      mav.addObject("bcateno", bcontentsVO_old.getBcateno());
      System.out.println("-> bcateno: " + bcontentsVO_old.getBcateno());
      
      return mav; // forward
    }   
    
    /**
     * 삭제 폼
     * @param bcontentsno
     * @return
     */
    @RequestMapping(value="/bcontents/delete.do", method=RequestMethod.GET )
    public ModelAndView delete(int bcontentsno) { 
      ModelAndView mav = new  ModelAndView();
      
      // 삭제할 정보를 조회하여 확인
      BcontentsVO bcontentsVO = this.bcontentsProc.read(bcontentsno);
      BcateVO bcateVO = this.bcateProc.read(bcontentsVO.getBcateno());
      BcategrpVO bcategrpVO = this.bcategrpProc.read(bcateVO.getBcategrpno());
      
      mav.addObject("bcontentsVO", bcontentsVO);
      mav.addObject("bcateVO", bcateVO);
      mav.addObject("bcategrpVO", bcategrpVO);
      
      mav.setViewName("/bcontents/delete");  // bcontents/delete.jsp
      
      return mav; 
    }

    /**
     * 삭제 처리 http://localhost:9091/bcontents/delete.do
     * 
     * @return
     */
    @RequestMapping(value = "/bcontents/delete.do", method = RequestMethod.POST)
    public ModelAndView delete(HttpServletRequest request, BcontentsVO bcontentsVO, 
                                            int now_page,
                                            @RequestParam(value="word", defaultValue="") String word) {
      ModelAndView mav = new ModelAndView();
      int bcontentsno = bcontentsVO.getBcontentsno();
      
      HashMap<String, Object> passwd_map = new HashMap<String, Object>();
      passwd_map.put("bcontentsno", bcontentsVO.getBcontentsno());
      passwd_map.put("passwd", bcontentsVO.getPasswd());
      
      int cnt = 0;
      int passwd_cnt = this.bcontentsProc.passwd_check(passwd_map);
      if (passwd_cnt == 1) { // 패스워드 일치 -> 등록된 파일 삭제 -> 신규 파일 등록
          // -------------------------------------------------------------------
          // 파일 삭제 코드 시작
          // -------------------------------------------------------------------
          // 삭제할 파일 정보를 읽어옴.
          BcontentsVO vo = bcontentsProc.read(bcontentsno);
//          System.out.println("bcontentsno: " + vo.getContentsno());
//          System.out.println("file1: " + vo.getFile1());
          
          String file1saved = vo.getFile1saved();
          String thumb1 = vo.getThumb1();
          long size1 = 0;
          boolean sw = false;
          
          // 완성된 경로 F:/ai8/ws_frame/resort_v1sbm3a/src/main/resources/static/bcontents/storage/
          String upDir =  System.getProperty("user.dir") + "/src/main/resources/static/contents/storage/"; // 절대 경로

          sw = Tool.deleteFile(upDir, file1saved);  // Folder에서 1건의 파일 삭제
          sw = Tool.deleteFile(upDir, thumb1);     // Folder에서 1건의 파일 삭제
          // System.out.println("sw: " + sw);
          // -------------------------------------------------------------------
          // 파일 삭제 종료 시작
          // -------------------------------------------------------------------
          
          cnt = this.bcontentsProc.delete(bcontentsno); // DBMS 삭제
          
          // -------------------------------------------------------------------------------------
          System.out.println("-> bcateno: " + vo.getBcateno());
          System.out.println("-> word: " + word);
          
          // 마지막 페이지의 레코드 삭제시의 페이지 번호 -1 처리
          HashMap<String, Object> page_map = new HashMap<String, Object>();
          page_map.put("bcateno", vo.getBcateno());
          page_map.put("word", word);
          // 10번째 레코드를 삭제후
          // 하나의 페이지가 3개의 레코드로 구성되는 경우 현재 9개의 레코드가 남아 있으면
          // 페이지수를 4 -> 3으로 감소 시켜야함.
          if (bcontentsProc.search_count(page_map) % Bcontents.RECORD_PER_PAGE == 0) {
            now_page = now_page - 1;
            if (now_page < 1) {
              now_page = 1; // 시작 페이지
            }
          }
          // -------------------------------------------------------------------------------------
          
          mav.addObject("now_page", now_page);
          mav.setViewName("redirect:/bcontents/list_by_cateno_search_paging.do"); 

      } else { // 패스워드 오류
          mav.addObject("cnt", cnt);
          mav.addObject("code", "passwd_fail");
          mav.addObject("url", "/bcontents/msg"); 
          mav.setViewName("redirect:/bcontents/msg.do");
      }
      mav.addObject("bcateno", bcontentsVO.getBcateno());
      System.out.println("-> bcateno: " + bcontentsVO.getBcateno());
      
      return mav; // forward
    }   
}