package dev.mvc.byou;

/*
        youno                               NUMBER(7)        NOT NULL        PRIMARY KEY,
        title                               VARCHAR2(50)         NOT NULL,
        url                                 VARCHAR2(1000)       NOT NULL,
        rdate                               DATE         NOT NULL,
        ytgrpno                             NUMBER(7)        NULL ,
        FOREIGN KEY (ytgrpno) REFERENCES ytgrp (ytgrpno)
*/
public class YouVO {
    /** 즐겨찾기 번호 */
    private int youno;
    /**  즐겨찾기 이름 */
    private String title;
    /** 즐겨찾기 주소 */
    private String url;
    /** 등록일 */
    private String rdate;
    /** 즐겨찾기 그룹 번호(FK) */
    private int ytgrpno;
    public YouVO() {
        
    }
    public YouVO(int youno, String title, String url, String rdate, int ytgrpno) {
        super();
        this.youno = youno;
        this.title = title;
        this.url = url;
        this.rdate = rdate;
        this.ytgrpno = ytgrpno;
    }
    /**
     * @return the youno
     */
    public int getYouno() {
        return youno;
    }
    /**
     * @param youno the youno to set
     */
    public void setYouno(int youno) {
        this.youno = youno;
    }
    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }
    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }
    /**
     * @return the url
     */
    public String getUrl() {
        return url;
    }
    /**
     * @param url the url to set
     */
    public void setUrl(String url) {
        this.url = url;
    }
    /**
     * @return the rdate
     */
    public String getRdate() {
        return rdate;
    }
    /**
     * @param rdate the rdate to set
     */
    public void setRdate(String rdate) {
        this.rdate = rdate;
    }
    /**
     * @return the ytgrpno
     */
    public int getYtgrpno() {
        return ytgrpno;
    }
    /**
     * @param ytgrpno the ytgrpno to set
     */
    public void setYtgrpno(int ytgrpno) {
        this.ytgrpno = ytgrpno;
    }
}