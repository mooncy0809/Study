package dev.mvc.bcate;

public class Bcategrp_BcateVO {
  /** 카테고리 그룹 번호 */
  private int r_bcategrpno;
  /**  카테고리 이름 */
  private String r_name;
  
  
  /** 카테고리 번호 */
  private int bcateno;  
  /** 카테고리 그룹 번호 */
  private int bcategrpno;
  /** 카테고리 이름 */
  private String name;
  /** 등록일 */
  private String rdate;
  /** 등록된 글 수 */
  private int cnt;
  
  public Bcategrp_BcateVO() {
        
  }

  public int getR_bcategrpno() {
    return r_bcategrpno;
  }
  public void setR_bcategrpno(int r_bcategrpno) {
    this.r_bcategrpno = r_bcategrpno;
  }
  public String getR_name() {
    return r_name;
  }
  public void setR_name(String r_name) {
    this.r_name = r_name;
  }
  public int getBcateno() {
    return bcateno;
  }
  public void setBcateno(int bcateno) {
    this.bcateno = bcateno;
  }
  public int getBcategrpno() {
    return bcategrpno;
  }
  public void setBcategrpno(int bcategrpno) {
    this.bcategrpno = bcategrpno;
  }
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }
  public String getRdate() {
    return rdate;
  }
  public void setRdate(String rdate) {
    this.rdate = rdate;
  }
  public int getCnt() {
    return cnt;
  }
  public void setCnt(int cnt) {
    this.cnt = cnt;
  }
  
  @Override
  public String toString() {
    return "[r_bcategrpno=" + r_bcategrpno + ", r_name=" + r_name + ", bcateno=" + bcateno + ", bcategrpno="
        + bcategrpno + ", name=" + name + ", rdate=" + rdate + ", cnt=" + cnt + "]";
  }
    
}
