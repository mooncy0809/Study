package dev.mvc.bcate;

import java.util.List;

public interface BcateDAOInter {
  /**
   * 등록
   * @param cateVO
   * @return 등록된 갯수
   */
  public int create(BcateVO bcateVO);
  /**
   *  전체 목록
   * @return
   */
  public List<BcateVO> list_all();  
  /**
   *  bcategrpno별 목록
   * @return
   */
  public List<BcateVO> list_by_categrpno(int bcategrpno);  
  
  /**
   * Categrp + Cate join, 연결 목록
   * @return
   */
  public List<Bcategrp_BcateVO> list_all_join();  
}