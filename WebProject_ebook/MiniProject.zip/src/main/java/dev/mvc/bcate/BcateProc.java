package dev.mvc.bcate;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component("dev.mvc.bcate.BcateProc")
public class BcateProc implements BcateProcInter {

  @Autowired
  private BcateDAOInter bcateDAO;
 
  public BcateProc() {
    System.out.println("-> CateProc created");
  }
  
  @Override
  public int create(BcateVO bcateVO) {
    int cnt = this.bcateDAO.create(bcateVO);
    return cnt;
  }
  @Override
  public List<BcateVO> list_all() {
      List<BcateVO> list = this.bcateDAO.list_all();
      return list;
  }
  @Override
  public List<BcateVO> list_by_categrpno(int bcategrpno) {
    List<BcateVO> list = this.bcateDAO.list_by_categrpno(bcategrpno);
    
    return list;
  }
  
  @Override
  public List<Bcategrp_BcateVO> list_all_join() {
    List<Bcategrp_BcateVO> list = this.bcateDAO.list_all_join();
    return list;
  }
  @Override
  public BcateVO read(int bcateno) {
      BcateVO bcateVO = this.bcateDAO.read(bcateno);
    return bcateVO;
  }

  @Override
  public int update(BcateVO bcateVO) {
    int cnt = this.bcateDAO.update(bcateVO);
    return cnt;
  }
  @Override
  public int delete(int bcateno) {
    int cnt = this.bcateDAO.delete(bcateno);
    return cnt;
  }
}