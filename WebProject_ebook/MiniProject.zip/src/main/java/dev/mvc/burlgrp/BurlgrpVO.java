package dev.mvc.burlgrp;

/*
        urlgrpno                            NUMBER(7)        NOT NULL        PRIMARY KEY,
        title                               VARCHAR2(50)         NOT NULL,
        cnt                                 NUMBER(10)       NOT NULL,
        visible                             VARCHAR2(1)      DEFAULT 'Y'         NOT NULL,
        rdate                               DATE         NOT NULL
 */

public class BurlgrpVO {
    /** 즐겨찾기 그룹 번호 */
    private int urlgrpno;
    /**  즐겨찾기 그룹 이름 */
    private String title;
    /** 관련 자료 개수 */
    private int cnt;
    /** 출력 모드 */
    private String visible;
    /** 등록일 */
    private String rdate;
    
    public BurlgrpVO(int urlgrpno, String title, int cnt, String visible, String rdate) {
        super();
        this.urlgrpno = urlgrpno;
        this.title = title;
        this.cnt = cnt;
        this.visible = visible;
        this.rdate = rdate;
    }
    public BurlgrpVO() {
        
    }
    /**
     * @return the urlgrpno
     */
    public int getUrlgrpno() {
        return urlgrpno;
    }
    /**
     * @param urlgrpno the urlgrpno to set
     */
    public void setUrlgrpno(int urlgrpno) {
        this.urlgrpno = urlgrpno;
    }
    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }
    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }
    /**
     * @return the cnt
     */
    public int getCnt() {
        return cnt;
    }
    /**
     * @param cnt the cnt to set
     */
    public void setCnt(int cnt) {
        this.cnt = cnt;
    }
    /**
     * @return the visible
     */
    public String getVisible() {
        return visible;
    }
    /**
     * @param visible the visible to set
     */
    public void setVisible(String visible) {
        this.visible = visible;
    }
    /**
     * @return the rdate
     */
    public String getRdate() {
        return rdate;
    }
    /**
     * @param rdate the rdate to set
     */
    public void setRdate(String rdate) {
        this.rdate = rdate;
    }
}
