package dev.mvc.burlgrp;

import java.util.List;

public interface BurlgrpProcInter {
    /**
     * 등록
     * @param burlgrpVO
     * @return 등록된 레코드 갯수
     */
    public int create(BurlgrpVO burlgrpVO);
    
    /**
     * 등록 순서별 목록
     * @return
     */
    public List<BurlgrpVO> list_urlgrpno_asc();
    
    /**
     * 조회, 수정폼
     * @param categrpno 카테고리 그룹 번호, PK
     * @return
     */
    public BurlgrpVO read(int urlgrpno);
    
    /**
     * 수정 처리
     * @param burlgrpVO
     * @return 처리된 레코드 갯수
     */
    public int update(BurlgrpVO burlgrpVO);
    
    /**
     * 삭제 처리
     * @param urlgrpno
     * @return 처리된 레코드 갯수
     */
    public int delete(int urlgrpno);
    /**
     * visible 수정
     * @param categrpVO
     * @return
     */
    public int update_visible(BurlgrpVO burlgrpVO);
}
