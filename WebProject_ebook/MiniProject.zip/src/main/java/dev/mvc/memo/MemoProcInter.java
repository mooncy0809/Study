package dev.mvc.memo;

import java.util.HashMap;
import java.util.List;


public interface MemoProcInter {
    /**
     * 등록
     * @param memoVO
     * @return
     */
    public int create(MemoVO memoVO);
    
    /**
     * sw 수정
     * @param memoVO
     * @return
     */
  //  public int update_sw(MemoVO memoVO);
    
    /**
     * 조회
     * @param memono
     * @return
     */
    public MemoVO read(int memono);
    
    /**
     * 검색 레코드 갯수
     * @param hashMap
     * @return
     */
    public int search_count(HashMap<String, Object> hashMap);
    
    /**
     * 검색 + 페이징 목록
     * @param map
     * @return
     */
    public List<MemoVO> list(HashMap<String, Object> map);
    
    /**
     * 페이지 목록 문자열 생성, Box 형태
     * @param bcategrpno 카테고리번호
     * @param search_count 검색 갯수
     * @param now_page 현재 페이지, now_page는 1부터 시작
     * @param word 검색어
     * @return
     */
    public String pagingBox(int search_count, int now_page, String word);
    
    /**
     * 텍스트 수정용 조회
     * @param memono
     * @return
     */
    public MemoVO read_update_text(int memono);

    /**
     * 텍스트 정보 수정
     * @param memoVO
     * @return
     */
    public int update_text(MemoVO memoVO);
    
    /**
     * 파일 정보 수정
     * @param memoVO
     * @return
     */
    public int update_file(MemoVO memoVO);
    
    /**
     * 삭제
     * @param memono
     *
     * @return
     */
    public int delete(int memono);
}
