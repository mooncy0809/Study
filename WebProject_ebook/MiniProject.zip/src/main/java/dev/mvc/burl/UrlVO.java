package dev.mvc.burl;
/*
urlno                               NUMBER(7)        NOT NULL        PRIMARY KEY,
title                               VARCHAR2(50)         NOT NULL,
url                                 VARCHAR2(1000)       NOT NULL,
rdate                               DATE         NOT NULL,
urlgrpno                            NUMBER(7)        NOT NULL,
*/
public class UrlVO {
    /** 즐겨찾기 번호 */
    private int urlno;
    /**  즐겨찾기 이름 */
    private String title;
    /** 즐겨찾기 주소 */
    private String url;
    /** 등록일 */
    private String rdate;
    /** 즐겨찾기 그룹 번호(FK) */
    private int urlgrpno;
    public UrlVO(int urlno, String title, String url, String rdate, int urlgrpno) {
        super();
        this.urlno = urlno;
        this.title = title;
        this.url = url;
        this.rdate = rdate;
        this.urlgrpno = urlgrpno;
    }
    /**
     * @return the urlno
     */
    public int getUrlno() {
        return urlno;
    }
    /**
     * @param urlno the urlno to set
     */
    public void setUrlno(int urlno) {
        this.urlno = urlno;
    }
    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }
    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }
    /**
     * @return the url
     */
    public String getUrl() {
        return url;
    }
    /**
     * @param url the url to set
     */
    public void setUrl(String url) {
        this.url = url;
    }
    /**
     * @return the rdate
     */
    public String getRdate() {
        return rdate;
    }
    /**
     * @param rdate the rdate to set
     */
    public void setRdate(String rdate) {
        this.rdate = rdate;
    }
    /**
     * @return the urlgrpno
     */
    public int getUrlgrpno() {
        return urlgrpno;
    }
    /**
     * @param urlgrpno the urlgrpno to set
     */
    public void setUrlgrpno(int urlgrpno) {
        this.urlgrpno = urlgrpno;
    }    
    public UrlVO() {
        
    }
}
