package dev.mvc.burl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import dev.mvc.burlgrp.BurlgrpProcInter;
import dev.mvc.burlgrp.BurlgrpVO;


@Controller
public class UrlCont {
    @Autowired
    @Qualifier("dev.mvc.burlgrp.BurlgrpProc")
    private BurlgrpProcInter burlgrpProc;
    @Autowired
    @Qualifier("dev.mvc.burl.UrlProc")  // @Component("dev.mvc.burl.UrlProc")
    private UrlProcInter urlProc;

    public UrlCont() {
        System.out.println("-> UrlCont created.");
    }
    
    /**
     * 등록폼 
     * @return
     */
    @RequestMapping(value = "/burl/create.do", method = RequestMethod.GET)
    public ModelAndView create() {
      ModelAndView mav = new ModelAndView();
      mav.setViewName("/burl/create"); // /webapp/WEB-INF/views/burl/create.jsp

      return mav;
      
    }
    
    /**
     * 등록처리
     * @return
     */
    @RequestMapping(value = "/burl/create.do", method = RequestMethod.POST)
    public ModelAndView create(UrlVO urlVO) {
      ModelAndView mav = new ModelAndView();
      
      int cnt = this.urlProc.create(urlVO);
      System.out.println("등록 성공");

      mav.addObject("code", "create_success");
      mav.addObject("cnt", cnt);
      mav.addObject("urlgrpno", urlVO.getUrlgrpno());
      mav.addObject("title", urlVO.getTitle());
      mav.addObject("url",urlVO.getUrl());
      
      mav.setViewName("/burl/msg");
 
      return mav;
    }
    
    
    /**
     * 전체 목록
     * @return
     */
    @RequestMapping(value="/burl/list_all.do", method=RequestMethod.GET )
    public ModelAndView list_all() {
      ModelAndView mav = new ModelAndView();
      
      List<UrlVO> list = this.urlProc.list_all();
      mav.addObject("list", list); // request.setAttribute("list", list);

      mav.setViewName("/burl/list_all"); // /burl/list_all.jsp
      return mav;
    }
    /**
     * 카테고리 그룹별 전체 목록
     * http://localhost:9091/burl/list_by_urlgrpno.do?urlgrpno=1
     * @param urlgrpno 특정 그룹에 소속된 카테고리를 출력할 카테고리 그룹 번호   
     * @return
     */
    @RequestMapping(value="/burl/list_by_urlgrpno.do", method=RequestMethod.GET )
    public ModelAndView list_by_urlgrpno(int urlgrpno) {
      ModelAndView mav = new ModelAndView();
      
      List<UrlVO> list = this.urlProc.list_by_urlgrpno(urlgrpno);
      mav.addObject("list", list);

      BurlgrpVO  burlgrpVO = this.burlgrpProc.read(urlgrpno); // 카테고리 그룹 정보
      mav.addObject("burlgrpVO", burlgrpVO); 
      
      mav.setViewName("/burl/list_by_urlgrpno"); 
      return mav;
    }
    
    /**
     * Urlgrp + Url join, 연결 목록
     * http://localhost:9091/burl/list_all_join.do 
     * @return
     */
    @RequestMapping(value="/burl/list_all_join.do", method=RequestMethod.GET )
    public ModelAndView list_all_join() {
      ModelAndView mav = new ModelAndView();
      
      List<Urlgrp_UrlVO> list = this.urlProc.list_all_join();
      mav.addObject("list", list); 

      mav.setViewName("/burl/list_all_join");
      return mav;
    }
    
    /**
     * 조회 + 수정폼 http://localhost:9091/cate/read_update.do
     * 
     * @return
     */
    @RequestMapping(value = "/burl/read_update.do", method = RequestMethod.GET)
    public ModelAndView read_update(int urlno) {
      // int urlno = Integer.parseInt(request.getParameter("urlno"));

      ModelAndView mav = new ModelAndView();
      mav.setViewName("/burl/read_update"); // read_update.jsp

      // 카테고리 정보
      UrlVO urlVO = this.urlProc.read(urlno);
      mav.addObject("urlVO", urlVO);
      // request.setAttribute("urlVO", urlVO);
      
      int urlgrpno = urlVO.getUrlgrpno();
      
      // 카테고리 그룹 정보
      BurlgrpVO burlgrpVO = this.burlgrpProc.read(urlgrpno);
      mav.addObject("burlgrpVO", burlgrpVO);

      // 카테고리 목록
      List<UrlVO> list = this.urlProc.list_by_urlgrpno(urlgrpno);
      mav.addObject("list", list);

      return mav; // forward
    }
    
    /**
     * 수정 처리
     * 
     * @param urlVO
     * @return
     */
    @RequestMapping(value = "/burl/update.do", method = RequestMethod.POST)
    public ModelAndView update(UrlVO urlVO) {
      ModelAndView mav = new ModelAndView();

      int cnt = this.urlProc.update(urlVO);
      
      if (cnt == 1) {
          mav.addObject("urlgrpno", urlVO.getUrlgrpno());
          mav.setViewName("redirect:/burl/list_by_urlgrpno.do");
      } else {
          mav.addObject("code", "update_fail"); // request에 저장
          mav.addObject("cnt", cnt); // request에 저장
          mav.addObject("urlno", urlVO.getUrlno());
          mav.addObject("urlgrpno", urlVO.getUrlgrpno());
          mav.addObject("name", urlVO.getTitle());
          mav.addObject("url", "/burl/msg"); 
          
          mav.setViewName("/burl/msg"); 
          
      }
      
      return mav;
    }
 
    /**
     * 
     * @return
     */
    @RequestMapping(value = "/burl/read_delete.do", method = RequestMethod.GET)
    public ModelAndView read_delete(int urlno) {
      // int urlno = Integer.parseInt(request.getParameter("urlno"));
      ModelAndView mav = new ModelAndView();
      mav.setViewName("/burl/read_delete");

      UrlVO urlVO = this.urlProc.read(urlno);
      mav.addObject("urlVO", urlVO);
      int urlgrpno = urlVO.getUrlgrpno();
      
      BurlgrpVO burlgrpVO = this.burlgrpProc.read(urlgrpno);
      mav.addObject("burlgrpVO", burlgrpVO);
      

      List<UrlVO> list = this.urlProc.list_by_urlgrpno(urlgrpno);
      mav.addObject("list", list);

      return mav; // forward
    }
    
    /**
     * 삭제 처리
     * 
     * @param urlVO
     * @return
     */
    @RequestMapping(value = "/burl/delete.do", method = RequestMethod.POST)
    public ModelAndView delete(int urlno) {
      ModelAndView mav = new ModelAndView();
      // 삭제될 레코드 정보를 삭제하기전에 읽음
      UrlVO urlVO = this.urlProc.read(urlno); 
      
      int cnt = this.urlProc.delete(urlno);
      
      if (cnt == 1) {
          mav.addObject("urlgrpno", urlVO.getUrlgrpno());
          mav.setViewName("redirect:/burl/list_by_urlgrpno.do");
      } else {
          mav.addObject("code", "update_fail"); // request에 저장
          mav.addObject("cnt", cnt); // request에 저장
          mav.addObject("urlno", urlVO.getUrlno());
          mav.addObject("urlgrpno", urlVO.getUrlgrpno());
          mav.addObject("name", urlVO.getTitle());
          mav.addObject("url", "/burl/msg"); 
          
          mav.setViewName("/burl/msg"); // /WEB-INF/views/cate/msg.jsp
          
      }
      
      return mav;
    }
    
}
