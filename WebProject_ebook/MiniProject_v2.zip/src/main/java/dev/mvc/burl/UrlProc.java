package dev.mvc.burl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component("dev.mvc.burl.UrlProc")
public class UrlProc implements UrlProcInter {

  @Autowired
  private UrlDAOInter urlDAO;
 
  public UrlProc() {
    System.out.println("-> UrlProc created");
  }
  
  @Override
  public int create(UrlVO urlVO) {
    int cnt = this.urlDAO.create(urlVO);
    return cnt;
  }
  
  @Override
  public List<UrlVO> list_all() {
      List<UrlVO> list = this.urlDAO.list_all();
      return list;
  }
  @Override
  public List<UrlVO> list_by_urlgrpno(int urlgrpno) {
    List<UrlVO> list = this.urlDAO.list_by_urlgrpno(urlgrpno);
    
    return list;
  }
  
  @Override
  public List<Urlgrp_UrlVO> list_all_join() {
    List<Urlgrp_UrlVO> list = this.urlDAO.list_all_join();
    return list;
  }
  
  @Override
  public UrlVO read(int urlno) {
    UrlVO urlVO = this.urlDAO.read(urlno);
    return urlVO;
  }

  @Override
  public int update(UrlVO urlVO) {
    int cnt = this.urlDAO.update(urlVO);
    return cnt;
  }
  @Override
  public int delete(int urlno) {
    int cnt = this.urlDAO.delete(urlno);
    return cnt;
  }
}