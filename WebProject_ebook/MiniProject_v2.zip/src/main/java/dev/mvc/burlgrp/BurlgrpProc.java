package dev.mvc.burlgrp;
 
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
 
// Autowired 기능에의해 자동 할당될 때 사용되는 이름
@Component("dev.mvc.burlgrp.BurlgrpProc")
public class BurlgrpProc implements BurlgrpProcInter {
  /* DI: 객체가 필요한 곳에 객체를 자동으로 생성하여 할당
      Autowired: DI 사용 선언
     ① Spring이 자동으로 BurlgrpDAOInter를 구현(DAO class 생성)
     ② 객체 생성: private BurlgrpDAOInter burlgrpDAO = new BurlgrpDAO();
     ③ burlgrpDAO에 생성된 객체를 할당 */     
  @Autowired 
  private BurlgrpDAOInter burlgrpDAO;

  @Override
  public int create(BurlgrpVO burlgrpVO) {
    int cnt = burlgrpDAO.create(burlgrpVO);
    
    return cnt;
  }
  @Override
  public List<BurlgrpVO> list_urlgrpno_asc() {
    List<BurlgrpVO> list = this.burlgrpDAO.list_urlgrpno_asc();
    return list;
  }
  
  @Override
  public BurlgrpVO read(int urlgrpno) {
    BurlgrpVO burlgrpVO = this.burlgrpDAO.read(urlgrpno);  
    return burlgrpVO;
  }
  @Override
  public int update(BurlgrpVO burlgrpVO) {
    int cnt = 0;
    cnt = this.burlgrpDAO.update(burlgrpVO);
    
    return cnt;
  }
  
  @Override
  public int delete(int urlgrpno) {
    int cnt = this.burlgrpDAO.delete(urlgrpno);
    return cnt;
  }
  @Override
  public int update_visible(BurlgrpVO burlgrpVO) {
    int cnt = 0;
    if (burlgrpVO.getVisible().toUpperCase().equals("Y")) {
        burlgrpVO.setVisible("N");
    } else {
        burlgrpVO.setVisible("Y");
    }
    cnt = this.burlgrpDAO.update_visible(burlgrpVO);
    return cnt;
  }
}
 