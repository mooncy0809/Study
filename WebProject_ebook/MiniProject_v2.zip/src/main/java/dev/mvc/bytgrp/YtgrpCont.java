package dev.mvc.bytgrp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class YtgrpCont {
    @Autowired
    @Qualifier("dev.mvc.bytgrp.YtgrpProc")
    private YtgrpProcInter ytgrpProc;

    public YtgrpCont() {
        System.out.println("-> YtgrpCont created.");
    }

    // http://localhost:9091/ytgrp/create.do
    /**
     * 등록 폼
     * 
     * @return
     */
    @RequestMapping(value = "/bytgrp/create.do", method = RequestMethod.GET)
    public ModelAndView create() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("/bytgrp/create"); // webapp/WEB-INF/views/ytgrp/create.jsp

        return mav; // forward
    }

    // http://localhost:9091/ytgrp/create.do
    /**
     * 등록 처리
     * @param ytgrpVO
     * @return
     */
    @RequestMapping(value = "/bytgrp/create.do", method = RequestMethod.POST)
    public ModelAndView create(YtgrpVO ytgrpVO) { 

        ModelAndView mav = new ModelAndView();

        int cnt = this.ytgrpProc.create(ytgrpVO); // 등록 처리
        // cnt = 0; // error test
        
        mav.addObject("cnt", cnt);
       
        if (cnt == 1) {
            // System.out.println("등록 성공");
            
            mav.addObject("code", "create_success"); // request에 저장, request.setAttribute("code", "create_success")
            mav.setViewName("/bytgrp/msg"); 
            
            // response.sendRedirect("/bytgrp/list.do");
            // mav.setViewName("redirect:/bytgrp/list.do");
        } else {
            mav.addObject("code", "create_fail"); 
            mav.setViewName("/bytgrp/msg"); 
        }

        return mav; // forward
    }
    @RequestMapping(value="/bytgrp/list.do", method=RequestMethod.GET )
    public ModelAndView list() {
      ModelAndView mav = new ModelAndView();
      
      List<YtgrpVO> list = this.ytgrpProc.list_ytgrpno_asc();
      mav.addObject("list", list); // request.setAttribute("list", list);

      mav.setViewName("/bytgrp/list"); 
      return mav;
    }
 // http://localhost:9091/bytgrp/read_update.do?ytgrpno=1
    /**
     * 조회 + 수정폼
     * @param ytgrpno 조회할 카테고리 번호
     * @return
     */
    @RequestMapping(value="/bytgrp/read_update.do", method=RequestMethod.GET )
    public ModelAndView read_update(int ytgrpno) {
      // request.setAttribute("ytgrpno", int ytgrpno) 작동 안됨.
      
      ModelAndView mav = new ModelAndView();
      
      YtgrpVO ytgrpVO = this.ytgrpProc.read(ytgrpno);
      mav.addObject("ytgrpVO", ytgrpVO);  // request 객체에 저장
      
      List<YtgrpVO> list = this.ytgrpProc.list_ytgrpno_asc();
      mav.addObject("list", list);  // request 객체에 저장

      mav.setViewName("/bytgrp/read_update");
      return mav; // forward
    }
    
    /**
     * 수정 처리
     * 
     * @param ytgrpVO
     * @return
     */
    @RequestMapping(value = "/bytgrp/update.do", method = RequestMethod.POST)
    public ModelAndView update(YtgrpVO ytgrpVO) {
        // CategrpVO categrpVO <FORM> 태그의 값으로 자동 생성됨.
        // request.setAttribute("categrpVO", categrpVO); 자동 실행

        ModelAndView mav = new ModelAndView();

        int cnt = this.ytgrpProc.update(ytgrpVO);
        mav.addObject("cnt", cnt); // request에 저장

        // cnt = 0; // error test
        if (cnt == 1) {
            // System.out.println("수정 성공");
            // response.sendRedirect("/categrp/list.do");
            mav.setViewName("redirect:/bytgrp/list.do");
        } else {
            mav.addObject("code", "update"); // request에 저장, request.setAttribute("code", "update")
            mav.setViewName("/bytgrp/msg"); // /WEB-INF/views/categrp/msg.jsp
        }

        return mav;
    }
    
 // http://localhost:9091/categrp/read_delete.do
    /**
     * 조회 + 삭제폼
     * @param ytgrpno 조회할 카테고리 번호
     * @return
     */
    @RequestMapping(value="/bytgrp/read_delete.do", method=RequestMethod.GET )
    public ModelAndView read_delete(int ytgrpno) {
      ModelAndView mav = new ModelAndView();
      
      YtgrpVO ytgrpVO = this.ytgrpProc.read(ytgrpno); // 삭제할 자료 읽기
      mav.addObject("ytgrpVO", ytgrpVO);  // request 객체에 저장
      
      List<YtgrpVO> list = this.ytgrpProc.list_ytgrpno_asc();
      mav.addObject("list", list);  // request 객체에 저장

      mav.setViewName("/bytgrp/read_delete"); // read_delete.jsp
      return mav;
    }
    
    /**
     * 삭제
     * @param ytgrpno 조회할 카테고리 번호
     * @return
     */
    @RequestMapping(value="/bytgrp/delete.do", method=RequestMethod.POST )
    public ModelAndView delete(int ytgrpno) {
      ModelAndView mav = new ModelAndView();
      
      YtgrpVO ytgrpVO = this.ytgrpProc.read(ytgrpno); // 삭제 정보
      mav.addObject("ytgrpVO", ytgrpVO);  // request 객체에 저장
      
      int cnt = this.ytgrpProc.delete(ytgrpno); // 삭제 처리
      mav.addObject("cnt", cnt);  // request 객체에 저장
      
      mav.setViewName("/bytgrp/delete_msg"); // delete_msg.jsp

      return mav;
    }
    
    /**
     * 출력 모드의 변경
     * @param ytgrpVO
     * @return
     */
    @RequestMapping(value="/bytgrp/update_visible.do", 
        method=RequestMethod.GET )
    public ModelAndView update_visible(YtgrpVO ytgrpVO) {
      ModelAndView mav = new ModelAndView();
      
      int cnt = this.ytgrpProc.update_visible(ytgrpVO);
      
      mav.setViewName("redirect:/bytgrp/list.do"); // request 객체 전달 안됨. 
      
      return mav;
    }  
}