package dev.mvc.calc2;
 
import org.springframework.stereotype.Controller;
 
@Controller
public class Test3 {
 
  public Test3() {
    System.out.println("-> test3 객체 생성됨.");
  }
 
}
 