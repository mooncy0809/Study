package dev.mvc.calc;
 
import org.springframework.stereotype.Controller;
 
@Controller
public class Test {
  public Test(){
    System.out.println("-> test 객체 생성됨.");
  }
}