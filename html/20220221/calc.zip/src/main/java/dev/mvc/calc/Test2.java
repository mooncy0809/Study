package dev.mvc.calc;
 
public class Test2 {
 
  public Test2() {
    System.out.println("-> test2 객체 생성됨.");
  }
 
}