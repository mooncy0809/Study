package dev.boot.calc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalcApplicationTests {

	@Test
	void contextLoads() {
	}

}
